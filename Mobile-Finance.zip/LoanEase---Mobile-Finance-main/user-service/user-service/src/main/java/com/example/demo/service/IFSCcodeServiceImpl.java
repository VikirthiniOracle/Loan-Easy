package com.example.demo.service;

import com.example.demo.entity.IFSCcode;
import com.example.demo.repository.IFSCcodeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IFSCcodeServiceImpl implements IFSCcodeService {

	@Autowired
    private final IFSCcodeRepo ifscCodeRepo;

    
    public IFSCcodeServiceImpl(IFSCcodeRepo ifscCodeRepo) {
        this.ifscCodeRepo = ifscCodeRepo;
    }

    @Override
    public IFSCcode saveIFSCcode(IFSCcode ifscCode) {
        if (ifscCodeRepo.existsById(ifscCode.getIfscCode())) {
            throw new RuntimeException("IFSC Code '" + ifscCode.getIfscCode() + "' already exists.");
        }
        return ifscCodeRepo.save(ifscCode);
    }

    @Override
    public IFSCcode getIFSCcodeById(String ifscCode) {
        return ifscCodeRepo.findById(ifscCode)
                .orElseThrow(() -> new RuntimeException("IFSC Code not found: " + ifscCode));
    }

    @Override
    public List<IFSCcode> getAllIFSCcodes() {
        return ifscCodeRepo.findAll();
    }

    @Override
    public IFSCcode updateIFSCcode(String ifscCode, IFSCcode ifscCodeDetails) {
        if (!ifscCodeRepo.existsById(ifscCode)) {
            throw new RuntimeException("Cannot update. IFSC Code not found: " + ifscCode);
        }

        ifscCodeDetails.setIfscCode(ifscCode); // Ensure code stays same
        return ifscCodeRepo.save(ifscCodeDetails);
    }

    @Override
    public void deleteIFSCcode(String ifscCode) {
        if (!ifscCodeRepo.existsById(ifscCode)) {
            throw new RuntimeException("Cannot delete. IFSC Code not found: " + ifscCode);
        }

        ifscCodeRepo.deleteById(ifscCode);
    }
}
