package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.CardNumber;
import com.example.demo.vo.CardNumberDTO;

public interface CardNumberService {

    // Create a new card
	CardNumber saveCardNumber(CardNumberDTO cardNumber);

    // Get card by card number
    CardNumber getCardNumberById(String cardNumber);

    // Get all cards
    List<CardNumber> getAllCardNumbers();

    // Get cards for a specific user
    List<CardNumber> getCardsByUserId(Long userId);

    // Update card
    CardNumber updateCardNumber(String cardNumber, CardNumber cardNumberDetails);

    // Delete card
    void deleteCardNumber(String cardNumber);
}
