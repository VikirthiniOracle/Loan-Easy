package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepo;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepo userRepo;

    // Create a new user
    @Override
    public User create(User newUser) {
        Optional<User> existingUser = userRepo.findById(newUser.getUserId());

        if (existingUser.isPresent()) {
            throw new RuntimeException("User already exists with ID: " + newUser.getUserId());
        }

        return userRepo.save(newUser);
    }

    // Read a user by ID
    @Override
    public User read(Long userId) {
        return userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));
    }

    // Read all users
    @Override
    public List<User> readAll() {
        return userRepo.findAll();
    }

    // Update user details
    @Override
    public User update(User userToUpdate) {
        if (!userRepo.existsById(userToUpdate.getUserId())) {
            throw new RuntimeException("User not found for update with ID: " + userToUpdate.getUserId());
        }

        return userRepo.save(userToUpdate);
    }

    // Delete a user by ID
    @Override
    public void delete(Long userId) {
        if (!userRepo.existsById(userId)) {
            throw new RuntimeException("User not found for deletion with ID: " + userId);
        }

        userRepo.deleteById(userId);
    }
}
