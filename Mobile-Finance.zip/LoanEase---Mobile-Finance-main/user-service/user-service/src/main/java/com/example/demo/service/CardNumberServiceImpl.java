package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.CardNumber;
import com.example.demo.entity.IFSCcode;
import com.example.demo.entity.User;
import com.example.demo.repository.CardNumberRepo;
import com.example.demo.vo.CardNumberDTO;

@Service
public class CardNumberServiceImpl implements CardNumberService {

	@Autowired
    private final CardNumberRepo cardNumberRepo;
	
	@Autowired
	private IFSCcodeService ifscCodeService;

	@Autowired
	private UserService userService;


    public CardNumberServiceImpl(CardNumberRepo cardNumberRepo) {
        this.cardNumberRepo = cardNumberRepo;
    }

//    @Override
//    public CardNumber saveCardNumber(CardNumber cardNumber) {
//        String code = cardNumber.getIfscCode().getIfscCode();
//
//        Optional<IFSCcode> optionalIfsc = ifscRepo.findByIfscCode(code);
//
//        if (optionalIfsc.isPresent()) {
//            cardNumber.setIfscCode(optionalIfsc.get());
//        }
//        // else: will persist the new IFSC entity
//
//        // Check if card already exists
//        if (cardNumberRepo.existsById(cardNumber.getCardNumber())) {
//            throw new RuntimeException("Card with number '" + cardNumber.getCardNumber() + "' already exists.");
//        }
//
//        return cardNumberRepo.save(cardNumber);
//    }

    @Override
	public CardNumber saveCardNumber(CardNumberDTO dto) {
		// ✅ Check if Card already exists
		if (cardNumberRepo.existsById(dto.getCardNumber())) {
			throw new RuntimeException("Card with number " + dto.getCardNumber() + " already exists.");
		}

		// ✅ Validate user
		User user;
		try {
			user = userService.read(dto.getUserId()); // throws error if not found
		} catch (RuntimeException e) {
			throw new IllegalArgumentException("User with ID " + dto.getUserId() + " does not exist.");
		}

		IFSCcode ifsc;
		try {
			ifsc = ifscCodeService.getIFSCcodeById(dto.getIfscCode());
		} catch (RuntimeException e) {
			throw new IllegalArgumentException("This ifsc does not exist.");
		}

		if (dto.getCardLimit() <= 0) {
			throw new IllegalArgumentException("Card limit must be a positive number.");
		}

		if (dto.getCardType() == null || dto.getCardType().trim().isEmpty()) {
			throw new IllegalArgumentException("Card type must be provided.");
        }


		// ✅ Construct and save entity
		CardNumber card = new CardNumber();
		card.setCardNumber(dto.getCardNumber());
		card.setCardType(dto.getCardType());
		card.setCardLimit(dto.getCardLimit());
		card.setJoiningFee(dto.getJoiningFee());
		card.setAccountNo(dto.getAccountNo());

		card.setUser(user);
		card.setIfscCode(ifsc);
		return cardNumberRepo.save(card);
    }



    @Override
    public CardNumber getCardNumberById(String cardNumber) {
        return cardNumberRepo.findById(cardNumber)
                .orElseThrow(() -> new RuntimeException("Card not found with number: " + cardNumber));
    }

    @Override
    public List<CardNumber> getAllCardNumbers() {
        return cardNumberRepo.findAll();
    }

    @Override
    public List<CardNumber> getCardsByUserId(Long userId) {
        List<CardNumber> cards = cardNumberRepo.findByUser_UserId(userId);
        if (cards.isEmpty()) {
            throw new RuntimeException("No cards found for user with ID: " + userId);
        }
        return cards;
    }

    @Override
    public CardNumber updateCardNumber(String cardNumber, CardNumber cardNumberDetails) {
        if (!cardNumberRepo.existsById(cardNumber)) {
            throw new RuntimeException("Cannot update. Card not found with number: " + cardNumber);
        }

        cardNumberDetails.setCardNumber(cardNumber); // Ensure card number is not changed
        return cardNumberRepo.save(cardNumberDetails);
    }

    @Override
    public void deleteCardNumber(String cardNumber) {
        if (!cardNumberRepo.existsById(cardNumber)) {
            throw new RuntimeException("Cannot delete. Card not found with number: " + cardNumber);
        }

        cardNumberRepo.deleteById(cardNumber);
    }
}
