package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "ifsc_code_table")
public class IFSCcode {

    @Id
    private String ifscCode;

    private String bankName;
    
//    @OneToMany(mappedBy = "ifscCode")
//    private List<CardNumber> cards;

//    public List<CardNumber> getCards() {
//		return cards;
//	}
//
//	public void setCards(List<CardNumber> cards) {
//		this.cards = cards;
//	}

	public IFSCcode() {
        super();
        // Default constructor
    }

    public IFSCcode(String ifscCode, String bankName) {
        super();
        this.ifscCode = ifscCode;
        this.bankName = bankName;
    }

    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    // Optional display method
    public void showIFSCDetails() {
        System.out.println("IFSC Code   : " + ifscCode);
        System.out.println("Bank Name   : " + bankName);
        System.out.println("------------------------------------");
    }
}
