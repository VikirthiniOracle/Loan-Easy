package com.example.demo.vo;

public class EmailRequest {
	private String email;
	private String name;

	// Constructors
	public EmailRequest() {
	}

	public EmailRequest(String email, String name) {
		this.email = email;
		this.name = name;
	}

	// Getters and Setters
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}


