package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.IFSCcode;

public interface IFSCcodeService {

    // Create a new IFSC code
    IFSCcode saveIFSCcode(IFSCcode ifscCode);

    // Read IFSC code by ID
	IFSCcode getIFSCcodeById(String ifscCode);

    // Read all IFSC codes
    List<IFSCcode> getAllIFSCcodes();

    // Update an IFSC code
    IFSCcode updateIFSCcode(String ifscCode, IFSCcode ifscCodeDetails);

    // Delete IFSC code
    void deleteIFSCcode(String ifscCode);
}
