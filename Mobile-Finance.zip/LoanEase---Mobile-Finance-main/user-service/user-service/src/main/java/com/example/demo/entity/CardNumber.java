package com.example.demo.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "card_table")
public class CardNumber {

    @Id
    @Column(length = 20)
    private String cardNumber;  // Primary Key

    @ManyToOne(cascade = CascadeType.ALL) //directly adds new user from card post method
    @JoinColumn(name = "userId")  // Foreign key to User
    private User user;
    
	@ManyToOne
	@JoinColumn(name = "ifscCode")
//    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private IFSCcode ifscCode;


    private String cardType;
    private double cardLimit;
    private double joiningFee;
    private long accountNo;

    // No-arg constructor
    public CardNumber() {
    }

    // All-arg constructor
    public CardNumber(String cardNumber, String cardType, IFSCcode ifscCode,
                      double cardLimit, double joiningFee, User user, long accountNo) {
        this.cardNumber = cardNumber;
        this.cardType = cardType;
        this.ifscCode = ifscCode;
        this.cardLimit = cardLimit;
        this.joiningFee = joiningFee;
        this.user = user;
        this.accountNo = accountNo;
    }

    // Getters and Setters

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public IFSCcode getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(IFSCcode ifscCode) {
        this.ifscCode = ifscCode;
    }

    public double getCardLimit() {
        return cardLimit;
    }

    public void setCardLimit(double cardLimit) {
        this.cardLimit = cardLimit;
    }

    public double getJoiningFee() {
        return joiningFee;
    }

    public void setJoiningFee(double joiningFee) {
        this.joiningFee = joiningFee;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public long getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(long accountNo) {
        this.accountNo = accountNo;
    }

    // Optional method to display details
    public void showCardDetails() {
        System.out.println("Card Number   : " + cardNumber);
        System.out.println("Card Type     : " + cardType);
        System.out.println("IFSC Code     : " + (ifscCode != null ? ifscCode.getIfscCode() : "null"));
        System.out.println("Card Limit    : ₹" + cardLimit);
        System.out.println("Joining Fee   : ₹" + joiningFee);
        System.out.println("User ID       : " + (user != null ? user.getUserId() : "null"));
        System.out.println("Account No    : " + accountNo);
        System.out.println("------------------------------------");
    }
}
