package com.example.demo.controller;

import com.example.demo.entity.IFSCcode;
import com.example.demo.service.IFSCcodeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ifsc")
@CrossOrigin("*")  // Allows access from frontend (adjust if needed)
public class IFSCcodeController {

    @Autowired
    private IFSCcodeService ifscCodeService;

    // ➕ Create a new IFSC code
    @PostMapping
    public IFSCcode createIFSCcode(@RequestBody IFSCcode ifscCode) {
        return ifscCodeService.saveIFSCcode(ifscCode);
    }

    // 📖 Get IFSC code by ID
    @GetMapping("/{ifscCode}")
    public IFSCcode getIFSCcodeById(@PathVariable String ifscCode) {
        return ifscCodeService.getIFSCcodeById(ifscCode);
    }

    // 📖 Get all IFSC codes
    @GetMapping
    public List<IFSCcode> getAllIFSCcodes() {
        return ifscCodeService.getAllIFSCcodes();
    }

    // ✏️ Update an IFSC code
    @PutMapping("/{ifscCode}")
    public IFSCcode updateIFSCcode(@PathVariable String ifscCode, @RequestBody IFSCcode updatedIFSC) {
        return ifscCodeService.updateIFSCcode(ifscCode, updatedIFSC);
    }

    // ❌ Delete an IFSC code
    @DeleteMapping("/{ifscCode}")
    public String deleteIFSCcode(@PathVariable String ifscCode) {
        ifscCodeService.deleteIFSCcode(ifscCode);
        return "IFSC Code '" + ifscCode + "' deleted successfully.";
    }
}
