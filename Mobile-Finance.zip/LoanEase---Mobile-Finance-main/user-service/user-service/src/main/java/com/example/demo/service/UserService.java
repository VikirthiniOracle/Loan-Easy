package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.User;

public interface UserService {

    // Create a new user
    User create(User newUser);

    // Read a user by ID
    User read(Long userId);

    // Read all users
    List<User> readAll();

    // Update user details
    User update(User userToUpdate);

    // Delete a user by ID
    void delete(Long userId);
}
