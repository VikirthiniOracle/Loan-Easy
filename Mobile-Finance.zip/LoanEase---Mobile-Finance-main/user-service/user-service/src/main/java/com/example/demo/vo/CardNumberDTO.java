package com.example.demo.vo;

public class CardNumberDTO {
	private String cardNumber;
	private String cardType;
	private Double cardLimit;
	private double joiningFee;
	private long accountNo;

	private Long userId;
	private String ifscCode;

	public CardNumberDTO(String cardNumber, String cardType, double cardLimit, double joiningFee, long accountNo,
			Long userId, String ifscCode) {
		super();
		this.cardNumber = cardNumber;
		this.cardType = cardType;
		this.cardLimit = cardLimit;
		this.joiningFee = joiningFee;
		this.accountNo = accountNo;
		this.userId = userId;
		this.ifscCode = ifscCode;
	}

	public CardNumberDTO() {
		super();
	}

	// Getters and setters

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public double getCardLimit() {
		return cardLimit;
	}

	public void setCardLimit(double cardLimit) {
		this.cardLimit = cardLimit;
	}

	public double getJoiningFee() {
		return joiningFee;
	}

	public void setJoiningFee(double joiningFee) {
		this.joiningFee = joiningFee;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
}
