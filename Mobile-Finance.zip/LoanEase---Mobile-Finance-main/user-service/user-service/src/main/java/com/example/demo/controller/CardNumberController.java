package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.CardNumber;
import com.example.demo.service.CardNumberService;
import com.example.demo.vo.CardNumberDTO;

@RestController
@RequestMapping("/api/cards")
@CrossOrigin("*") // allows frontend access (adjust origin if needed)
public class CardNumberController {

    @Autowired
    private CardNumberService cardNumberService;

    // ➕ Create a new card
    @PostMapping
	public CardNumber createCard(@RequestBody CardNumberDTO card) {
        return cardNumberService.saveCardNumber(card);
    }

    // 📖 Get a specific card by card number
    @GetMapping("/{cardNumber}")
    public CardNumber getCardById(@PathVariable String cardNumber) {
        return cardNumberService.getCardNumberById(cardNumber);
    }

    // 📖 Get all cards
    @GetMapping
    public List<CardNumber> getAllCards() {
        return cardNumberService.getAllCardNumbers();
    }

    // 📖 Get all cards for a specific user
    @GetMapping("/user/{userId}")
    public List<CardNumber> getCardsByUser(@PathVariable Long userId) {
        return cardNumberService.getCardsByUserId(userId);
    }

    // ✏️ Update an existing card
    @PutMapping("/{cardNumber}")
    public CardNumber updateCard(@PathVariable String cardNumber, @RequestBody CardNumber updatedCard) {
        return cardNumberService.updateCardNumber(cardNumber, updatedCard);
    }

    // ❌ Delete a card by card number
    @DeleteMapping("/{cardNumber}")
    public String deleteCard(@PathVariable String cardNumber) {
        cardNumberService.deleteCardNumber(cardNumber);
        return "Card with number " + cardNumber + " deleted successfully.";
    }
}
