package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
@CrossOrigin("*") // Allow frontend access
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public User createUser(@RequestBody User newUser) {
        return userService.create(newUser);
    }

    @GetMapping("/{id}")
    public User getUser(@PathVariable Long id) {
        return userService.read(id);
    }

    @GetMapping
    public List<User> getAllUsers() {
        return userService.readAll();
    }

    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id, @RequestBody User userData) {
        userData.setUserId(id); // Ensure path ID matches object ID
        return userService.update(userData);
    }

    @DeleteMapping("/{id}")
    public String deleteUser(@PathVariable Long id) {
        userService.delete(id);
        return "User with ID " + id + " deleted successfully.";
    }
}
