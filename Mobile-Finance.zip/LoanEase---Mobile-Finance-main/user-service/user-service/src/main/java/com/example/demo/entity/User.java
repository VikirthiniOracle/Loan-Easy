package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "user_table")
public class User {

    @Id
    private Long userId;
    
//    @OneToMany(mappedBy = "user")
//    private List<Loan> loans;
//
//    @OneToMany(mappedBy = "user")
//    private List<CardNumber> cards;

	private String email;
    private String phone;
    private String address;
    private String password;
    private String name;
    private String panCardNo;
	private String status;
	private String cardType;
	private String account;
	private String ifsc;

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public User() {
        super();
        // Default constructor
    }

    public User(Long userId, String email, String phone, String address,
			String password, String name, String panCardNo, String status, String cardType, String account) {
        super();
        this.userId = userId;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.password = password;
        this.name = name;
        this.panCardNo = panCardNo;
		this.status = status;
		this.cardType = cardType;
		this.account = account;
		this.ifsc = ifsc;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPanCardNo() {
        return panCardNo;
    }

    public void setPanCardNo(String panCardNo) {
        this.panCardNo = panCardNo;
    }

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
//    public List<Loan> getLoans() {
//		return loans;
//	}
//
//	public void setLoans(List<Loan> loans) {
//		this.loans = loans;
//	}
//
//	public List<CardNumber> getCards() {
//		return cards;
//	}
//
//	public void setCards(List<CardNumber> cards) {
//		this.cards = cards;
//	}

    // Optional: Method to display user details
    public void display() {
        System.out.println("----- USER DETAILS -----");
        System.out.println("User ID    : " + userId);
        System.out.println("Email      : " + email);
        System.out.println("Phone      : " + phone);
        System.out.println("Address    : " + address);
        System.out.println("Password   : " + password);
        System.out.println("Name       : " + name);
        System.out.println("PanCard No : " + panCardNo);
        System.out.println("------------------------");
    }
}
