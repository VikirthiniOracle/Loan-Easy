define(['knockout', 'ojs/ojarraydataprovider'], function (ko, ArrayDataProvider) {
  function RequestPageViewModel() {
    const self = this;

    self.applicantList = ko.observableArray([]);
    self.applicantDataProvider = new ArrayDataProvider(self.applicantList, {
      keyAttributes: 'userId',
    });

    // 🔄 Fetch only Pending applicants from backend
    async function fetchApplicants() {
      try {
        const response = await fetch('http://localhost:8081/api/users');
        const data = await response.json();
        console.log(data);
        // ✅ Only keep applicants with status 'Pending'
        const pendingApplicants = data.filter((user) => user.status === 'Pending');
        self.applicantList(pendingApplicants);
      } catch (error) {
        console.error('Error fetching applicants:', error);
      }
    }

    // Reusable email function
async function sendEmail(to, subject, message) {
  try {
    const response = await fetch('http://localhost:3000/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        recipient: to,
        subject: subject,
        message: message,
      }),
    });

    if (!response.ok) {
      console.error('Failed to send email:', await response.text());
    } else {
      console.log('Email sent to:', to);
    }
  } catch (error) {
    console.error('Error sending email:', error);
  }
}

function generateRandom7DigitNumber() {
  return Math.floor(1000000 + Math.random() * 9000000).toString();
}

// Your existing approveApplicant function with card creation logic
self.approveApplicant = async function (applicant) {
  try {
      // Step 1: Update user status to 'Approved'
      const updatedUser = { ...applicant, status: 'Approved' };

      const userUpdateResponse = await fetch(`http://localhost:8081/api/users/${applicant.userId}`, {
          method: 'PUT',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify(updatedUser),
      });

      if (userUpdateResponse.ok) {
          console.log('Approved and user status updated:', applicant.name);
          self.applicantList.remove(applicant);

          // Step 2: Prepare card data based on applicant's details
          const cardNumber = generateRandom7DigitNumber();
          let cardLimit = 0;
          let joiningFee = 0;

          // Determine cardLimit and joiningFee based on cardType
          if (applicant.cardType && applicant.cardType.toLowerCase() === 'gold') {
              cardLimit = 50000;
              joiningFee = 1000;
          } else if (applicant.cardType && applicant.cardType.toLowerCase() === 'titanium') {
              cardLimit = 150000;
              joiningFee = 2000;
          } else {
              // Default values if cardType is neither gold nor titanium, or undefined
              console.warn(`Applicant ${applicant.userId} has unrecognized cardType: ${applicant.cardType}. Using default cardLimit and joiningFee.`);
              cardLimit = 25000; // Example default
              joiningFee = 500;   // Example default
          }

          const cardData = {
              cardNumber: cardNumber,
              userId: applicant.userId,
              ifscCode: applicant.ifsc, // Assuming ifscCode exists on the applicant object
              cardType: applicant.cardType, // Use the applicant's cardType
              cardLimit: cardLimit,
              joiningFee: joiningFee,
              accountNo: applicant.account // Assuming accountNo exists on the applicant object
          };

          // Step 3: Make POST request to create the card
          console.log('Attempting to create card with data:', cardData);
          const cardCreationResponse = await fetch('http://localhost:8081/api/cards', {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
              },
              body: JSON.stringify(cardData),
          });

          if (cardCreationResponse.ok) {
              console.log('Card successfully created for:', applicant.name, 'Card Number:', cardNumber);
              // Send approval email after successful card creation
              await sendEmail(
                  applicant.email,
                  'Loan Application Approved & Card Issued',
                  `Hi ${applicant.name},\n\nCongratulations!! Your loan application has been approved and a new ${applicant.cardType} card (Card Number: ${cardNumber}) has been issued to you.\n\nRegards,\nLoanEase Team`
              );
          } else {
              const errorText = await cardCreationResponse.text();
              console.error('Card creation failed for', applicant.name, ':', errorText);
              // Optionally revert user status or send a different email if card creation fails
              alert(`Approval successful, but card creation failed for ${applicant.name}: ${errorText}`);
          }

      } else {
          const errorText = await userUpdateResponse.text();
          console.error('Approval failed (user status update):', errorText);
          alert(`Failed to approve applicant ${applicant.name}: ${errorText}`);
      }
  } catch (error) {
      console.error('Error approving applicant or creating card:', error);
      alert(`An unexpected error occurred during approval or card creation for ${applicant.name}.`);
  }
};
    // ✅ Reject applicant — delete user from DB
    self.rejectApplicant = async function (applicant) {
  try {
    const response = await fetch(
      `http://localhost:8081/api/users/${applicant.userId}`,
      {
        method: 'DELETE',
      }
    );

    if (response.ok) {
      console.log('Rejected:', applicant.name);
      self.applicantList.remove(applicant);
      await sendEmail(
        applicant.email,
        'Loan Application Rejected',
        `Hi ${applicant.name},\n\nWe regret to inform you that your loan application has been rejected.\n\nRegards,\nLoanEase Team`
      );

    } else {
      console.error('Rejection failed:', await response.text());
    }
  } catch (error) {
    console.error('Error rejecting applicant:', error);
  }
};


    // Initial fetch
    fetchApplicants();
  }

  return RequestPageViewModel;
});
