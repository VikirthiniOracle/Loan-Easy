// define([
//   'ojs/ojcore',
//   'knockout',
//   'ojs/ojarraydataprovider',
//   'ojs/ojlistview',
//   'ojs/ojbutton',
//   'ojs/ojdialog',
//   'ojs/ojinputtext',
//   'ojs/ojformlayout'
// ], function (oj, ko, ArrayDataProvider) {
//   function DashboardViewModel() {
//     var self = this;

//     // Sample data with imageUrl
//     self.phones = ko.observableArray([
//       {
//         id: 1,
//         name: "iPhone 14 Pro",
//         price: 129000,
//         specs: "128GB, A16 Bionic, 48MP Camera",
//         imageUrl: "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-14-pro-finish-select-202209-6-1inch-deeppurple_AV1?wid=512&hei=512&fmt=jpeg"
//       },
//       {
//         id: 2,
//         name: "Samsung Galaxy S23",
//         price: 89999,
//         specs: "256GB, Snapdragon 8 Gen 2, 50MP Camera",
//         imageUrl: "https://images.samsung.com/in/smartphones/galaxy-s23-ultra/images/galaxy-s23-ultra-highlights-kv.jpg"
//       }
//     ]);

//     self.phoneDataProvider = new ArrayDataProvider(self.phones, { keyAttributes: 'id' });

//     // New mobile form fields (including imageUrl)
//     self.newMobile = {
//       name: ko.observable(''),
//       price: ko.observable(''),
//       specs: ko.observable(''),
//       imageUrl: ko.observable('')
//     };

//     // Open Add Dialog
//     self.openAddDialog = function () {
//       document.getElementById('addDialog').open();
//     };

//     // Close Add Dialog
//     self.closeAddDialog = function () {
//       document.getElementById('addDialog').close();
//     };

//     // Add new phone with image
//     self.addPhone = function () {
//       if (
//         self.newMobile.name() &&
//         self.newMobile.price() &&
//         self.newMobile.specs() &&
//         self.newMobile.imageUrl()
//       ) {
//         const newId = Date.now(); // Unique ID
//         self.phones.push({
//           id: newId,
//           name: self.newMobile.name(),
//           price: parseInt(self.newMobile.price()),
//           specs: self.newMobile.specs(),
//           imageUrl: self.newMobile.imageUrl()
//         });

//         // Clear form fields
//         self.newMobile.name('');
//         self.newMobile.price('');
//         self.newMobile.specs('');
//         self.newMobile.imageUrl('');
//         self.closeAddDialog();
//       } else {
//         alert("Please fill in all fields.");
//       }
//     };

//     // Delete phone
//     self.deletePhone = function (id) {
//       self.phones.remove(function (phone) {
//         return phone.id === id;
//       });
//     };
//   }

//   return new DashboardViewModel();
// });

define([
  'ojs/ojcore',
  'knockout',
  'ojs/ojarraydataprovider',
  'ojs/ojlistview',
  'ojs/ojbutton',
  'ojs/ojdialog',
  'ojs/ojinputtext',
  'ojs/ojformlayout'
], function (oj, ko, ArrayDataProvider) {
  function DashboardViewModel() {
    const self = this;
    self.phones = ko.observableArray([]);
    self.phoneDataProvider = new ArrayDataProvider(self.phones, { keyAttributes: 'deviceId' });


    // Load from backend
    self.loadPhones = async function () {
      try {
        const response = await fetch("http://localhost:8082/devices");
        if (!response.ok) throw new Error("Failed to fetch");
        const data = await response.json();
        self.phones(data); // assuming data is array of {deviceId, name, price, specs, imageUrl}
      } catch (err) {
        console.error("Error loading phones:", err);
      }
    };

    // New mobile form fields
    self.newMobile = {
      mobileModel: ko.observable(''),
      price: ko.observable(''),
      specs: ko.observable(''),
      // imageUrl: ko.observable('')
    };

    // Open / Close Dialog
    self.openAddDialog = () => document.getElementById('addDialog').open();
    self.closeAddDialog = () => document.getElementById('addDialog').close();

    // Add to backend
    self.addPhone = async function () {
      const newDevice = {
        mobileModel: self.newMobile.mobileModel(),
        price: parseFloat(self.newMobile.price()),
        deviceStatus: "active", // or any status you want
        // imageUrl: self.newMobile.imageUrl() // Only if you're storing this
      };

      try {
        const response = await fetch("http://localhost:8082/devices", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(newDevice)
        });

        if (!response.ok) throw new Error("Failed to add mobile");

        const savedDevice = await response.json();
        self.phones.push(savedDevice); // backend returns saved object
        self.closeAddDialog();

        // Clear form
        self.newMobile.mobileModel('');
        self.newMobile.price('');
        self.newMobile.deviceStatus('');
        // self.newMobile.imageUrl('');
      } catch (err) {
        console.error("Error adding phone:", err);
      }
    };

    // Delete from backend
    self.deletePhone = async function (id) {
      try {
        const response = await fetch(`http://localhost:8082/devices/${id}`, {
          method: "DELETE"
        });

        if (!response.ok) throw new Error("Failed to delete mobile");

        self.phones.remove(phone => phone.deviceId === id);
      } catch (err) {
        console.error("Error deleting phone:", err);
      }
    };

    self.loadPhones(); // Load on init
  }

  return new DashboardViewModel();
});
