define([
  'knockout',
  'ojs/ojarraydataprovider',
  'ojs/ojchart'
], function (ko) {
  function DashboardViewModel() {
    const self = this;

    // KPI Values
    self.totalUsers = ko.observable(10);
    self.approvedLoans = ko.observable(7);
    self.pendingRequests = ko.observable(3);

    // Pie Chart Data
    self.cardTypeSeries = ko.observableArray([
      { name: 'Gold', items: [70] },
      { name: 'Titanium', items: [55] }
    ]);

    // Bar Chart Data
    self.mobileGroups = ko.observableArray(['Redmi Note 13', 'iPhone 15', 'Samsung M14']);
    self.mobileSeries = ko.observableArray([
      { name: 'Mobiles', items: [30, 25, 18] }
    ]);

    self.userGrowthGroups = ko.observableArray(["2019", "2020", "2021", "2022", "2023", "2024", "2025"]);

    self.userGrowthSeries = ko.observableArray([
  { name: "Users", items: [100, 300, 600, 1000, 1500, 2200, 3100] }
]);

  }

  return DashboardViewModel;
});
