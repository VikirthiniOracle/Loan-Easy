define([
  'ojs/ojcore',
  'knockout',
  'ojs/ojarraydataprovider',
  'ojs/ojtable',
  'jquery'
], function (oj, ko, ArrayDataProvider, ojTable, $) {
  function CustomerViewModel() {
    var self = this;

    self.users = ko.observableArray([]);
    self.userDataProvider = new ArrayDataProvider(self.users, { keyAttributes: 'userId' });

    self.fetchUsers = function () {
      $.ajax({
        url: 'http://localhost:8081/api/users',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
          const transformed = data
            .filter(user => user.status === 'Approved') // ✅ filter active only
            .map(user => ({
              userId: user.userId,
              name: user.name,
              email: user.email,
              phone: user.phone,
              address: user.address,
              password: user.password,
              panCardNo: user.panCardNo,
              status: user.status,
              cardType: user.cardType,
              account : user.account
             
            }));

          self.users(transformed);
          console.log(self.users());
        },
        error: function (xhr, status, error) {
          console.error('Failed to fetch users:', error);
          alert('Error fetching users from server.');
        }
      });
    };

    self.fetchUsers();
   
  }

  return CustomerViewModel;
});
