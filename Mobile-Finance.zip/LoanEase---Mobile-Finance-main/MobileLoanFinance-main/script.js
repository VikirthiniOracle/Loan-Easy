// Global state
let currentUser = null;
let currentPage = "home";
let products = []; // This will now hold the merged product data
let users = [];
let applications = [];
let purchases = [];

document.addEventListener("DOMContentLoaded", () => {
  const ifscDropdown = document.getElementById("ifsc");

  fetch("http://localhost:8081/api/ifsc") 
      .then(response => {
          if (!response.ok) {
              throw new Error("Failed to fetch IFSC codes");
          }
          return response.json();
      })
      .then(ifscList => {
          ifscList.forEach(entry => {
              const option = document.createElement("option");
              option.value = entry.ifscCode;
              option.textContent = `${entry.ifscCode}`;
              ifscDropdown.appendChild(option);
          });
      })
      .catch(error => {
          console.error("Error loading IFSC codes:", error);
          const errorOption = document.createElement("option");
          errorOption.value = "";
          errorOption.textContent = "Error loading IFSC codes";
          ifscDropdown.appendChild(errorOption);
      });
});


// Static data: specs and images
const sampleProducts = [
  {
    mobileModel: "iPhone 15 Pro", // matches backend "mobileModel"
    image: "./assets/iphone15.jpg",
    specs: {
      Display: "6.1-inch Super Retina XDR",
      Processor: "A17 Pro chip",
      Storage: "128GB",
      Camera: "48MP Main + 12MP Ultra Wide",
      Battery: "Up to 23 hours video playback",
    },
  },
  {
    mobileModel: "Samsung Galaxy S24 Ultra",
    image: "./assets/samsung-s24.jpg",
    specs: {
      Display: "6.8-inch Dynamic AMOLED 2X",
      Processor: "Snapdragon 8 Gen 3",
      Storage: "256GB",
      Camera: "200MP Main + 50MP Periscope",
      Battery: "5000mAh",
    },
  },
  {
    mobileModel: "OnePlus 12",
    image: "./assets/oneplus12.jpg",
    specs: {
      Display: "6.82-inch LTPO AMOLED",
      Processor: "Snapdragon 8 Gen 3",
      Storage: "256GB",
      Camera: "50MP Main + 64MP Periscope",
      Battery: "5400mAh",
    },
  },
  {
    mobileModel: "Xiaomi 14 Ultra",
    image: "./assets/xiaomi.jpg",
    specs: {
      Display: "6.73-inch LTPO AMOLED",
      Processor: "Snapdragon 8 Gen 3",
      Storage: "512GB",
      Camera: "50MP Main + 50MP Ultra Wide",
      Battery: "5300mAh",
    },
  },
  {
    mobileModel: "iPhone 14",
    image: "./assets/iphone14.jpg",
    specs: {
      Display: "6.1-inch Super Retina XDR",
      Processor: "A15 Bionic chip",
      Storage: "128GB",
      Camera: "12MP Main + 12MP Ultra Wide",
      Battery: "Up to 20 hours video playback",
    },
  },
  {
    mobileModel: "Samsung Galaxy A54",
    image: "./assets/samsunga24.jpg",
    specs: {
      Display: "6.4-inch Super AMOLED",
      Processor: "Exynos 1380",
      Storage: "128GB",
      Camera: "50MP Main + 12MP Ultra Wide",
      Battery: "5000mAh",
    },
  },
];

// Initialize app
document.addEventListener("DOMContentLoaded", () => {
  initializeApp();
  setupEventListeners();
  loadSampleData();
});

function initializeApp() {
  // Load data from localStorage
  users = JSON.parse(localStorage.getItem("users")) || [];
  applications = JSON.parse(localStorage.getItem("applications")) || [];
  purchases = JSON.parse(localStorage.getItem("purchases")) || [];
  currentUser = JSON.parse(localStorage.getItem("currentUser")) || null;

  // Update UI based on login status
  updateNavigation();

  // Show home page by default
  showPage("home");
}

function loadSampleData() {
  loadProducts(); // that's it!
}

function setupEventListeners() {
  // Navigation
  document.querySelectorAll("[data-page]").forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const page = e.target.getAttribute("data-page");
      showPage(page);
    });
  });

  // Hamburger menu
  const hamburger = document.getElementById("hamburger");
  const navMenu = document.getElementById("nav-menu");

  hamburger.addEventListener("click", () => {
    navMenu.classList.toggle("active");
  });

  // Forms
  document.getElementById("register-form").addEventListener("submit", handleRegister);
  document.getElementById("login-form").addEventListener("submit", handleLogin);

  // Login tabs
  document.querySelectorAll(".login-tabs .tab-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      document.querySelectorAll(".login-tabs .tab-btn").forEach((b) => b.classList.remove("active"));
      e.target.classList.add("active");
    });
  });

  // Admin tabs
  document.querySelectorAll(".admin-tabs .tab-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const tab = e.target.getAttribute("data-tab");
      showAdminTab(tab);
    });
  });

  // Filters
  document.getElementById("brand-filter").addEventListener("change", filterProducts);
  document.getElementById("price-filter").addEventListener("change", filterProducts);

  // Modal
  const modal = document.getElementById("emi-modal");
  const closeBtn = document.querySelector(".close");

  closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
  });

  window.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.style.display = "none";
    }
  });

  // EMI calculator
  document.getElementById("emi-months").addEventListener("change", calculateEMI);
}

function showPage(page) {
  // Hide all pages
  document.querySelectorAll(".page").forEach((p) => p.classList.remove("active"));

  // Show selected page
  const targetPage = document.getElementById(`${page}-page`);
  if (targetPage) {
    targetPage.classList.add("active");
    currentPage = page;

    // Load page-specific content
    switch (page) {
      case "dashboard":
        if (currentUser) {
          loadDashboard();
        } else {
          showPage("login");
        }
        break;
      case "admin":
        if (currentUser && currentUser.role === "admin") {
          loadAdminPanel();
        } else {
          showPage("login");
        }
        break;
      case "products":
        // ⭐ FIX: Ensure products are rendered when navigating to this page
        renderProducts(products); 
        break;
      case "payment":
          // Payment page content is loaded dynamically by showPaymentPage
        break;
    }
  }
}

function handleRegister(e) {
  e.preventDefault();

  // Generate a unique ID for the user on the frontend
  const newUserId = Math.floor(Math.random() * (20000 - 1000 + 1)) + 1000; // This generates a unique ID like 'a1b2c3d4-e5f6-7890-1234-567890abcdef'

  const formData = new FormData(e.target);
  const userData = {
    id: newUserId, // ⭐ Using the newly generated UUID as the local 'id'
    fullName: formData.get("fullName"),
    email: formData.get("email"),
    phone: formData.get("phone"),
    password: formData.get("password"),
    cardType: formData.get("cardType"),
    account: formData.get("account"),
    ifsc: formData.get("ifsc"),
    pan: formData.get("pan"),
    income: formData.get("income"),
    status: "pending",
    appliedDate: new Date().toISOString(),
    role: "user",
  };

  // Check if user already exists locally (good immediate feedback)
  // This check now uses the 'email' as the unique identifier for existing applications
  if (applications.find((app) => app.email === userData.email)) {
    alert("User with this email already exists with a pending application!");
    return;
  }
  if (users.find((user) => user.email === userData.email)) {
    alert("User with this email is already registered!");
    return;
  }

  // Prepare data for the backend API
  const userForBackend = {
    userId: newUserId, // ⭐ Sending the generated UUID as 'userId' to the backend
    email: userData.email,
    phone: userData.phone,
    address: "mumbai", // Placeholder: Consider adding an address field to your form
    password: userData.password,
    name: userData.fullName,
    panCardNo: userData.pan,
    status: "Pending",
    cardType: userData.cardType,
    account : userData.account,
    ifsc : userData.ifsc
  };

  // Add to applications array locally first
  applications.push(userData);
  localStorage.setItem("applications", JSON.stringify(applications));

  // Now, send data to the backend
  fetch("http://localhost:8081/api/users", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(userForBackend),
  })
    .then(async (response) => {
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: "Unknown error" }));
        throw new Error(
          `Failed to register user in backend: ${response.status} ${response.statusText} - ${
            errorData.message || ""
          }`,
        );
      }
      return response.json(); // Backend might return the user data, potentially with the same userId
    })
    .then((createdUser) => {
      console.log("User successfully registered in backend:", createdUser);
      // At this point, you could verify 'createdUser.userId' matches 'newUserId' if needed.
      // For now, we assume the backend accepts and uses the provided userId.

      alert("Application submitted successfully! You will be notified once approved.");
      e.target.reset();
      showPage("login");
    })
    .catch((error) => {
      console.error("Error registering user in backend:", error);
      alert(
        `Application submitted locally, but failed to register with our system. Please try again later or contact support. Error: ${error.message}`,
      );

      // Optionally, if backend registration is critical, you might want to
      // remove the locally added application or mark it as 'backend_failed'
      // applications = applications.filter(app => app.id !== newUserId);
      // localStorage.setItem("applications", JSON.stringify(applications));

      e.target.reset(); // Still clear the form and go to login page
      showPage("login");
    });
}

function handleLogin(e) {
  e.preventDefault();

  const formData = new FormData(e.target);
  const email = formData.get("email");
  const password = formData.get("password");
  const isAdmin = document.querySelector(".login-tabs .tab-btn.active").getAttribute("data-tab") === "admin";

  // Admin login (remains local as per your current implementation)
  if (isAdmin) {
    if (email === "admin@mobilefin.com" && password === "admin123") {
      currentUser = {
        id: "admin",
        email: "admin@mobilefin.com",
        fullName: "Admin",
        role: "admin",
      };
      localStorage.setItem("currentUser", JSON.stringify(currentUser));
      updateNavigation();
      showPage("admin");
      return;
    } else {
      alert("Invalid admin credentials!");
      return;
    }
  }

  // User login - Fetch users from backend
  fetch("http://localhost:8081/api/users")
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return response.json();
    })
    .then(backendUsers => {
      // Find the user by email in the backend data
      const user = backendUsers.find((u) => u.email === email);

      // Check 1: User existence
      if (!user) {
        alert("User doesn't exist!");
        // Do not redirect anywhere
        return;
      }

      // Check 2: User approval status
      // ⭐ Assuming your backend user object (like the one returned by /api/users)
      // includes a 'status' field (e.g., "pending", "approved", "rejected").
      // If your backend User model doesn't have 'status', you'll need to
      // manage approval status on the frontend or fetch it from another backend endpoint.
      // For this example, I'll assume the 'status' property is part of the backend user object.
      if (user.status !== "Approved" ) {
        alert("User is not approved yet!");
        // Do not redirect anywhere
        return;
      }

      // Check 3: Password match (only if user exists and is approved)
      if (user.password === password) {
        // Login successful and approved
        currentUser = {
          id: user.userId, // Use userId from backend
          email: user.email,
          fullName: user.name, // Use 'name' from backend for fullName
          role: "user",
          phone: user.phone,
          address: user.address,
          panCardNo: user.panCardNo,
          // ⭐ IMPORTANT: Fetch cardType from your local 'users' array or another source,
          // as it's not present in the backend user example you provided.
          // This assumes `users` global array holds users that were locally approved
          // and have their cardType stored.
         // cardType: users.find(localUser => localUser.email === user.email)?.cardType || "default",
        };
        localStorage.setItem("currentUser", JSON.stringify(currentUser));
        updateNavigation();
        showPage("dashboard"); // Redirect to dashboard
      } else {
        // Password incorrect
        alert("Invalid credentials!");
        // Do not redirect anywhere
      }
    })
    .catch(error => {
      console.error("Error fetching users for login:", error);
      alert("Failed to connect to the login system. Please try again later.");
      // Do not redirect anywhere on fetch error
    });
}

function logout() {
  currentUser = null;
  localStorage.removeItem("currentUser");
  updateNavigation();
  showPage("home");
}

function updateNavigation() {
  const loginNav = document.getElementById("login-nav");
  const registerNav = document.getElementById("register-nav");
  const logoutNav = document.getElementById("logout-nav");
  const dashboardNav = document.getElementById("dashboard-nav");
  const adminNav = document.getElementById("admin-nav");

  if (currentUser) {
    loginNav.style.display = "none";
    registerNav.style.display = "none";
    logoutNav.style.display = "block";
    dashboardNav.style.display = "block";

    if (currentUser.role === "admin") {
      adminNav.style.display = "block";
    } else {
      adminNav.style.display = "none";
    }
  } else {
    loginNav.style.display = "block";
    registerNav.style.display = "block";
    logoutNav.style.display = "none";
    dashboardNav.style.display = "none";
    adminNav.style.display = "none";
  }
}

// Make loadDashboard async because we'll be using await inside
async function loadDashboard() {
  const userInfo = document.getElementById("user-info");
  const cardDisplay = document.getElementById("card-display");
  const availableLimitElement = document.getElementById("available-limit");
  const usedLimitElement = document.getElementById("used-limit");
  const activeLoansCount = document.getElementById("active-loans");
  const totalEmiLeft = document.getElementById("total-emi-left");

  // User info - This part remains the same
  userInfo.innerHTML = `
      <div>
          <strong>${currentUser.fullName}</strong><br>
          <small>${currentUser.email}</small>
      </div>
  `;

  // Clear previous display while fetching
  cardDisplay.innerHTML = '<p>Loading card details...</p>';
  availableLimitElement.textContent = 'Loading...';
  usedLimitElement.textContent = 'Loading...';
  activeLoansCount.textContent = 'Loading...';
  totalEmiLeft.textContent = 'Loading...';
  document.getElementById("active-loans-container").innerHTML = '<p class="no-data">Loading loans...</p>';


  try {
      // --- Step 1: Fetch Card Data (needed for cardNumber and currentAvailableLimit) ---
      const cardsResponse = await fetch("http://localhost:8081/api/cards");

      if (!cardsResponse.ok) {
          throw new Error(`HTTP error fetching cards: ${cardsResponse.status}`);
      }

      const backendCards = await cardsResponse.json();
      const userCard = backendCards.find(card => card.user.userId === currentUser.id);

      let cardLimit = 0; // Represents the total limit based on cardType
      let displayCardType = 'N/A';
      let currentAvailableLimit = 0; // This is the actual current available limit from the fetched card

      if (userCard) {
          // cardLimit refers to the total limit of the card type (e.g., 150000 for titanium)
          cardLimit = userCard.cardType === "titanium" ? 150000 : 50000;
          displayCardType = userCard.cardType;
          currentAvailableLimit = userCard.cardLimit; // Use the cardLimit from the fetched userCard as the current available balance
          currentUser.cardType = userCard.cardType;
          localStorage.setItem("currentUser", JSON.stringify(currentUser)); // Store updated currentUser
      } else {
          console.warn(`No card found for user ID: ${currentUser.id}. Displaying default card information.`);
          cardLimit = 0;
          displayCardType = 'default';
          currentAvailableLimit = 0;
      }

      // Update Card display
      cardDisplay.innerHTML = `
          <div class="card-display ${displayCardType}">
              <h2>${displayCardType.toUpperCase()} CARD</h2>             
              <h3>${currentUser.fullName.toUpperCase()}</h3>
              <p>Total Limit: ₹${cardLimit.toLocaleString()}</p>
              <p>Available Limit: ₹${currentAvailableLimit.toLocaleString()}</p>
          </div>
          
      `;

      // Update individual stat cards
      availableLimitElement.textContent = `₹${currentAvailableLimit.toLocaleString()}`;
      usedLimitElement.textContent = `₹${(cardLimit - currentAvailableLimit).toLocaleString()}`;

      // --- Step 2: Fetch Loans for the Specific Card (ONLY if a card was found) ---
      let loansWithPaymentInfo = []; // Initialize as empty array
      if (userCard && userCard.cardNumber) {
          try {
              const loansResponse = await fetch(`http://localhost:8083/api/loans/card/${userCard.cardNumber}`);

              if (!loansResponse.ok) {
                  throw new Error(`HTTP error fetching loans: ${loansResponse.status}`);
              }
              const backendLoans = await loansResponse.json();

              // Process fetched loans to include necessary display data
              loansWithPaymentInfo = await Promise.all(backendLoans.map(async (loan) => {
                  // ⭐ IMPORTANT: This is where you would fetch paid installments from your EMI table.
                  // As per your previous note: "if the emi table returns no emis for this loan yet then that would mean that no emi payments have been done"
                  let paidInstallments = 0; // Default to 0 if no EMI payments or service not integrated yet

               
                  try {
                      const emiPaymentsResponse = await fetch(`http://localhost:8083/api/emi/loan/${loan.loanID}`);
                      if (emiPaymentsResponse.ok) {
                          const payments = await emiPaymentsResponse.json();
                          paidInstallments = payments.length; // Assuming each entry is one paid EMI
                      }
                  } catch (emiError) {
                      console.warn(`Could not fetch EMI payments for loan ${loan.loanID}:`, emiError);
                  }

                  return {
                      ...loan,
                      productName: products.find(p => p.deviceId === loan.deviceId)?.mobileModel || `Product ID ${loan.deviceId}`, // Get product name from local 'products' array
                      amount: loan.loanAmount,
                      emiAmount: loan.monthlyEMI,
                      emiMonths: loan.emiPlan, // This is expected to be a number from backend now
                      startDate: loan.loanStartDate,
                      paidInstallments: paidInstallments, // From EMI service or defaulted to 0
                  };
              }));

          } catch (loanFetchError) {
              console.error("Error fetching loans for card:", loanFetchError);
              // Continue with card data displayed, but show error for loans
              document.getElementById("active-loans-container").innerHTML = `<p class="error-message">Could not load loans. Error: ${loanFetchError.message}</p>`;
              activeLoansCount.textContent = 'Error';
              totalEmiLeft.textContent = 'Error';
              return; // Exit if loan fetching fails, as subsequent calculations depend on it
          }
      } else {
           // If no userCard or cardNumber, there are no loans to fetch for this user
          console.log("No card found for user, skipping loan fetch.");
          document.getElementById("active-loans-container").innerHTML = '<p class="no-data">No active loans.</p>';
      }


      // --- Step 3: Calculate Loan Statistics and Render ---
      const activeLoans = loansWithPaymentInfo.filter(loan => loan.status === "active");
      
      const totalEmiRemaining = activeLoans.reduce((sum, loan) => {
          const remainingInstallments = loan.emiMonths - loan.paidInstallments;
          return sum + (loan.monthlyEMI * Math.max(0, remainingInstallments)); // Ensure it's not negative
      }, 0);
      
      activeLoansCount.textContent = activeLoans.length;
      totalEmiLeft.textContent = `₹${totalEmiRemaining.toLocaleString()}`;
      
      // Pass the processed active loans to loadActiveLoans
      loadActiveLoans(activeLoans);

  } catch (error) {
      console.error("Error loading dashboard data:", error);
      alert(`Failed to load dashboard data: ${error.message}. Please ensure all backend services (Card, Device, Loan) are running.`);
      cardDisplay.innerHTML = `<p class="error-message">Could not load card details. Error: ${error.message}</p>`;
      availableLimitElement.textContent = 'Error';
      usedLimitElement.textContent = 'Error';
      activeLoansCount.textContent = 'Error';
      totalEmiLeft.textContent = 'Error';
      document.getElementById("active-loans-container").innerHTML = `<p class="error-message">Could not load loans. Error: ${error.message}</p>`;
  }
}



function loadActiveLoans(activeLoans) {
  const container = document.getElementById("active-loans-container");

  if (activeLoans.length === 0) {
    container.innerHTML = '<p class="no-data">No active loans. <a href="#" data-page="products">Browse products</a></p>';
    return;
  }

  container.innerHTML = activeLoans
    .map((loan) => {
      const paidInstallments = loan.paidInstallments || 0;
      const totalInstallments = loan.emiMonths;
      const remainingInstallments = totalInstallments - paidInstallments;
      const progressPercentage = Math.round((paidInstallments / totalInstallments) * 100);

      const nextEmiDate = new Date(loan.loanStartDate);
      nextEmiDate.setMonth(nextEmiDate.getMonth() + paidInstallments + 1);

      const emiTimeline = generateEmiTimeline(loan, paidInstallments, totalInstallments);

      const paymentDetails = {
        loanId: loan.loanID,
        emiAmount: loan.emiAmount,
        dueDate: nextEmiDate.toISOString(), // Due date in ISO format
        emiNumberDue: paidInstallments + 1 // The next EMI number to be paid
      };

      const paymentDetailsString = JSON.stringify(paymentDetails).replace(/"/g, '&quot;');

      let buttonHtml = '';
      let nextEmiInfoHtml = ''; // For the "22 Aug 2025 Next EMI Due Date" part
      let celebrationMessageHtml = ''; // Initialize celebration message

      // --- CONDITIONAL LOGIC FOR THE BOTTOM SECTION CONTENT ---
      if (remainingInstallments <= 0) {
        // If loan is completed, show celebration message and 'Close Loan' button
        celebrationMessageHtml = `
            <p class="celebration-message"> Congratulations! Your loan is fully paid. </p>
        `;
        buttonHtml = `
            <button class="complete-loan-button pay-emi-button" onclick="completeLoan('${loan.loanID}')">Close Loan</button>
        `;
        // No next EMI info for completed loans
        nextEmiInfoHtml = '';
      } else {
        // If loan is ongoing, show 'Pay Now' button and next EMI due date info
        buttonHtml = `
            <button class="pay-emi-button" onclick="payEmi(${paymentDetailsString})">Pay Now</button>
        `;
        nextEmiInfoHtml = `
            <div class="date-info">
                <span class="date">${nextEmiDate.toLocaleDateString("en-IN", {
                    day: "numeric",
                    month: "short",
                    year: "numeric",
                })}</span>
                <span class="label">Next EMI Due Date</span>
            </div>
        `;
        // No celebration message for ongoing loans
        celebrationMessageHtml = '';
      }
      // --- END CONDITIONAL LOGIC ---

      return `
          <div class="loan-card">
              <div class="loan-header">
                  <div class="loan-info">
                      <h4>${loan.productName}</h4>
                      <p>Loan started on ${new Date(loan.loanStartDate).toLocaleDateString()}</p>
                  </div>
                  <div class="loan-amount">
                      <span class="total-amount">₹${loan.amount.toLocaleString()}</span>
                      <span class="emi-amount">₹${loan.emiAmount}/month</span>
                  </div>
              </div>

              <div class="loan-progress">
                  <div class="progress-header">
                      <span class="progress-text">${paidInstallments} of ${totalInstallments} EMIs paid</span>
                      <span class="progress-percentage">${progressPercentage}%</span>
                  </div>
                  <div class="progress-bar">
                      <div class="progress-fill" style="width: ${progressPercentage}%"></div>
                  </div>
              </div>

              <div class="emi-timeline">
                  ${emiTimeline}
              </div>

              <div class="loan-details">
                  <div class="detail-item">
                      <span class="detail-value">₹${(loan.emiAmount * remainingInstallments).toLocaleString()}</span>
                      <span class="detail-label">Amount Left</span>
                  </div>
                  <div class="detail-item">
                      <span class="detail-value">${remainingInstallments}</span>
                      <span class="detail-label">EMIs Left</span>
                  </div>
                  <div class="detail-item">
                      <span class="detail-value">₹${(loan.emiAmount * paidInstallments).toLocaleString()}</span>
                      <span class="detail-label">Paid Amount</span>
                  </div>
                  <div class="detail-item">
                      <span class="detail-value">${Math.floor(remainingInstallments / 12)}y ${
                        remainingInstallments % 12
                      }m</span>
                      <span class="detail-label">Time Left</span>
                  </div>
              </div>

              <div class="next-emi-section">
                 
                  <div class="next-emi-date">
                   ${celebrationMessageHtml}
                      ${nextEmiInfoHtml}
                      ${buttonHtml}
                  </div>
              </div>
          </div>
      `;
    })
    .join("");
}

function payEmi(paymentData) {
  console.log(paymentData)

  // Store payment data globally for the payment page
  window.currentPaymentData = paymentData

  // Show the payment page
  showPaymentPage(paymentData)
}

function showPaymentPage(paymentData) {
  // First ensure the payment page is shown
  showPage("payment")
  
  // Wait for the DOM to update, then get the container
  setTimeout(() => {
    const container = document.getElementById("payment-container")
    
    if (!container) {
      console.error("Payment container not found!")
      alert("Error loading payment page. Please try again.")
      showPage("dashboard")
      return
    }

    // Convert due date string to a readable format
    const dueDateObj = new Date(paymentData.dueDate)
    const formattedDueDate = dueDateObj.toLocaleDateString("en-IN", {
      day: "numeric",
      month: "long",
      year: "numeric",
    })

    container.innerHTML = `
      <div class="payment-card">
        <div class="payment-header">
          <button class="back-btn" onclick="showPage('dashboard')">
            <i class="fas fa-arrow-left"></i>
            Back to Dashboard
          </button>
          <h2>EMI Payment</h2>
        </div>
        
        <div class="payment-content">
          <div class="payment-info">
            <div class="payment-detail-card">
              <h3>Payment Details</h3>
              <div class="payment-details">
                <div class="detail-row">
                  <span class="detail-label">Loan ID:</span>
                  <span class="detail-value">${paymentData.loanId}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">EMI Number:</span>
                  <span class="detail-value">${paymentData.emiNumberDue}</span>
                </div>
                <div class="detail-row">
                  <span class="detail-label">Due Date:</span>
                  <span class="detail-value">${formattedDueDate}</span>
                </div>
                <div class="detail-row amount-row">
                  <span class="detail-label">Amount to Pay:</span>
                  <span class="detail-value amount">₹${paymentData.emiAmount.toLocaleString()}</span>
                </div>
              </div>
            </div>
            
            <div class="payment-form-card">
              <h3>Payment Method</h3>
              <form id="payment-form" onsubmit="processPayment(event)">
                <div class="form-group">
                  <label for="upi-id">
                    <i class="fas fa-mobile-alt"></i>
                    UPI ID
                  </label>
                  <input 
                    type="text" 
                    id="upi-id" 
                    name="upiId" 
                    placeholder="yourname@paytm / yourname@gpay"
                    required
                    pattern="[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+"
                    title="Please enter a valid UPI ID (e.g., yourname@paytm)"
                  >
                </div>
                
                <div class="payment-summary">
                  <div class="summary-row">
                    <span>EMI Amount:</span>
                    <span>₹${paymentData.emiAmount.toLocaleString()}</span>
                  </div>
                  <div class="summary-row">
                    <span>Processing Fee:</span>
                    <span>₹0</span>
                  </div>
                  <div class="summary-row total-row">
                    <span>Total Amount:</span>
                    <span>₹${paymentData.emiAmount.toLocaleString()}</span>
                  </div>
                </div>
                
                <button type="submit" class="btn btn-primary btn-large payment-btn">
                  <i class="fas fa-credit-card"></i>
                  Pay ₹${paymentData.emiAmount.toLocaleString()}
                </button>
              </form>
            </div>
          </div>
          
          <div class="payment-security">
            <div class="security-info">
              <i class="fas fa-shield-alt"></i>
              <div>
                <h4>Secure Payment</h4>
                <p>Your payment is protected with bank-grade security</p>
              </div>
            </div>
            <div class="security-features">
              <div class="security-feature">
                <i class="fas fa-lock"></i>
                <span>256-bit SSL Encryption</span>
              </div>
              <div class="security-feature">
                <i class="fas fa-check-circle"></i>
                <span>PCI DSS Compliant</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    `
  }, 10) // Small delay to ensure DOM is updated
}

function processPayment(event) {
  event.preventDefault();

  const formData = new FormData(event.target);
  const upiId = formData.get("upiId");
  const paymentData = window.currentPaymentData; // Get payment data from global variable

  if (!upiId || !paymentData) {
    alert("Please enter a valid UPI ID and ensure payment data is available.");
    return;
  }

  // Show loading state
  const submitBtn = event.target.querySelector('button[type="submit"]');
  const originalText = submitBtn.innerHTML;
  submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
  submitBtn.disabled = true;

  // --- Calculate fields needed for both requests ---
  const currentPaymentDate = new Date();
  const dueDateObj = new Date(paymentData.dueDate);
  
  const paymentStatus = currentPaymentDate > dueDateObj ? "late" : "good";


  // Generate IDs
  const emiPaymentID = Math.floor(100000 + Math.random() * 900000); // 6-digit integer
  const transactionId = Math.floor(10000 + Math.random() * 900000); // 5-6 digit integer

  // --- Prepare data for EMI update (POST to /api/emi) ---
  const emiPostData = {
    emiPaymentID: emiPaymentID,
    loanId: paymentData.loanId,
    emiNumber: paymentData.emiNumberDue,
    dueDate: paymentData.dueDate, // Use original due date string
    paymentDate: currentPaymentDate.toISOString(), // Current payment date
    amountPaid: paymentData.emiAmount,
    paymentStatus: paymentStatus,
  };

  // --- Prepare data for Transaction record (POST to /api/transactions) ---
  const transactionPostData = {
    transactionId: transactionId,
    transactionType: "emi-payment",
    amount: paymentData.emiAmount,
    transactionDate: currentPaymentDate.toISOString(), // Current transaction date
    paymentMethod: upiId, // Use the UPI ID from the form
    loanId: paymentData.loanId,
  };

  console.log("EMI Post Data:", emiPostData);
  console.log("Transaction Post Data:", transactionPostData);

  // --- Perform both POST requests concurrently using Promise.all ---
  Promise.all([
      // Request 1: Update EMI table
      fetch("http://localhost:8083/api/emi", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(emiPostData),
      }),
      // Request 2: Create Transaction record
      fetch("http://localhost:8083/api/transactions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(transactionPostData),
      }),
    ])
    .then((responses) => {
      // Check if both responses were successful (response.ok)
      const allResponsesOk = responses.every((response) => response.ok);

      if (!allResponsesOk) {
        // If any request failed, process all responses to get error details
        return Promise.all(
            responses.map((response) => {
              if (!response.ok) {
                // Attempt to read JSON error, fallback to text if not JSON
                return response.json().catch(() => response.text())
                  .then((errorDetails) => `Status: ${response.status}, Details: ${JSON.stringify(errorDetails || 'No details')}`);
              }
              return 'OK'; // Mark successful responses
            })
          )
          .then((errorMessages) => {
            // Filter out 'OK' messages and join the errors
            const failedMessages = errorMessages.filter(msg => msg !== 'OK').join('; ');
            throw new Error(`One or more payment operations failed. Errors: [${failedMessages}]`);
          });
      }
      // If all responses are OK, parse JSON from each and return
      return Promise.all(responses.map((response) => response.json()));
    })
    .then((data) => {
      console.log("All payment operations successful:", data);

      // Restore button state
      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;

      // Show success message, passing relevant data
      const finalPaymentDataForSuccess = {
        ...paymentData,
        paymentDate: currentPaymentDate.toISOString(),
        status: paymentStatus, // The calculated status
      };
      showPaymentSuccess(finalPaymentDataForSuccess);
    })
    .catch((error) => {
      console.error("Payment operations failed:", error);

      // Reset button state
      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;

      alert(`Payment failed: ${error.message}`);
    });
}

function showPaymentSuccess(paymentData) {
  const container = document.getElementById("payment-container")

  container.innerHTML = `
    <div class="payment-success-card">
      <div class="success-icon">
        <i class="fas fa-check-circle"></i>
      </div>
      
      <h2>Payment Successful!</h2>
      <p>Your EMI payment has been processed successfully</p>
      
      <div class="success-details">
        <div class="success-detail">
          <span class="label">Transaction ID:</span>
          <span class="value">TXN${Date.now()}</span>
        </div>
        <div class="success-detail">
          <span class="label">Amount Paid:</span>
          <span class="value">₹${paymentData.emiAmount.toLocaleString()}</span>
        </div>
        <div class="success-detail">
          <span class="label">Loan ID:</span>
          <span class="value">${paymentData.loanId}</span>
        </div>
        <div class="success-detail">
          <span class="label">Date & Time:</span>
          <span class="value">${new Date().toLocaleString("en-IN")}</span>
        </div>
      </div>
      
      <div class="success-actions">
        <button class="btn btn-primary" onclick="showPage('dashboard')">
          <i class="fas fa-home"></i>
          Back to Dashboard
        </button>
        <button class="btn btn-secondary" onclick="downloadReceipt()">
          <i class="fas fa-download"></i>
          Download Receipt
        </button>
      </div>
    </div>
  `
}


function downloadReceipt() {
  console.log("receipt data ");
  console.log(window.currentPaymentData);
  const paymentData = window.currentPaymentData;
  const receiptTransactionId = `TXN${Date.now()}`;

  // 1. Create a hidden container for the HTML receipt content
  const receiptContainer = document.createElement('div');
  receiptContainer.id = 'receipt-template'; // Give it an ID for html2canvas
  receiptContainer.style.position = 'absolute';
  receiptContainer.style.left = '-9999px';
  receiptContainer.style.width = '600px'; // Define a width for consistent image rendering
  document.body.appendChild(receiptContainer);

  
receiptContainer.innerHTML = `
<div style="font-family: Arial, sans-serif; padding: 20px; border: 1px solid #ddd; max-width: 600px; margin: 20px auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); color: #333;"> 
    <div style="text-align: center; margin-bottom: 20px;">
        <h1 style="color: #4CAF50; margin: 0;">LoanEase</h1>
        <p style="font-size: 14px; color: #555;">Your trusted partner for loans</p>
    </div>
    <h2 style="text-align: center; color: #333; border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 20px;">Payment Receipt</h2>
    
    <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
        <tr>
            <td style="padding: 8px 0; border-bottom: 1px dashed #eee; width: 50%; color: #333;"><strong>Receipt ID:</strong></td> 
            <td style="padding: 8px 0; border-bottom: 1px dashed #eee; text-align: right; color: #333;">${receiptTransactionId}</td> 
        </tr>
        <tr>
            <td style="padding: 8px 0; border-bottom: 1px dashed #eee; color: #333;"><strong>Date:</strong></td>
            <td style="padding: 8px 0; border-bottom: 1px dashed #eee; text-align: right; color: #333;">${new Date().toLocaleString("en-IN", { dateStyle: 'long', timeStyle: 'short' })}</td>
        </tr>
        <tr>
            <td style="padding: 8px 0; border-bottom: 1px dashed #eee; color: #333;"><strong>Loan ID:</strong></td> 
            <td style="padding: 8px 0; border-bottom: 1px dashed #eee; text-align: right; color: #333;">${paymentData.loanId}</td> 
        </tr>
        <tr>
            <td style="padding: 8px 0; border-bottom: 1px dashed #eee; color: #333;"><strong>EMI Number:</strong></td> 
            <td style="padding: 8px 0; border-bottom: 1px dashed #eee; text-align: right; color: #333;">${paymentData.emiNumberDue}</td> 
        </tr>
        <tr>
            <td style="padding: 8px 0; color: #333;"><strong>Amount Paid:</strong></td>
            <td style="padding: 8px 0; text-align: right; font-size: 18px; font-weight: bold; color: #333;">₹${paymentData.emiAmount.toLocaleString("en-IN")}</td>
        </tr>
    </table>

    <div style="text-align: center; padding: 15px; background-color: #e8f5e9; border-radius: 5px; margin-bottom: 20px;">
        <p style="font-size: 16px; color: #388e3c; margin: 0;"><strong>Payment Status: SUCCESS</strong></p>
    </div>

    <div style="text-align: center; font-size: 12px; color: #777;">
        <p>Thank you for your payment!</p>
        <p>LoanEase | Contact: support@loanease.com</p>
    </div>
</div>
`;

  // 2. Convert HTML to canvas, then to image
  html2canvas(receiptContainer, { scale: 2 }).then(canvas => { // Scale for better quality
      const imgData = canvas.toDataURL('image/png'); // or 'image/jpeg'

      // 3. Create a temporary link and trigger download
      const a = document.createElement('a');
      a.href = imgData;
      a.download = `LoanEase_Receipt_${paymentData.loanId}_${receiptTransactionId}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      // Clean up the temporary container
      document.body.removeChild(receiptContainer);
  });
}

function generateEmiTimeline(loan, paidInstallments, totalInstallments) {
  let timeline = "";
  const currentDate = new Date();
  const startDate = new Date(loan.startDate);

  for (let i = 1; i <= totalInstallments; i++) {
    const emiDate = new Date(startDate);
    emiDate.setMonth(emiDate.getMonth() + i);

    let status = "pending";
    let tooltip = `EMI ${i}: ${emiDate.toLocaleDateString("en-IN", { month: "short", year: "numeric" })}`;

    if (i <= paidInstallments) {
      status = "paid";
      tooltip += " - Paid ✓";
    } else if (i === paidInstallments + 1) {
      status = "current";
      tooltip += " - Due Now";
    } else if (emiDate < currentDate) {
      status = "overdue";
      tooltip += " - Overdue!";
    } else {
      tooltip += " - Pending";
    }

    timeline += `
      <div class="emi-installment ${status}" data-tooltip="${tooltip}">
        ${i}
      </div>
    `;
  }

  return timeline;
}

function renderProducts(productsToRender) {
  const productsGrid = document.getElementById("products-grid");
  const brandFilter = document.getElementById("brand-filter").value;
  const priceFilter = document.getElementById("price-filter").value;

  let filteredProducts = productsToRender;

  // Apply brand filter - now case-insensitive and checks for existence of brand property
  if (brandFilter) {
    filteredProducts = filteredProducts.filter((p) => p.brand?.toLowerCase() === brandFilter.toLowerCase());
  }

  // Apply price filter
  if (priceFilter) {
    const [min, max] = priceFilter.split("-").map(Number);
    if (max) {
      filteredProducts = filteredProducts.filter((p) => p.price >= min && p.price <= max);
    } else {
      filteredProducts = filteredProducts.filter((p) => p.price >= min);
    }
  }

  productsGrid.innerHTML = filteredProducts
    .map(
      (product) => `
        <div class="product-card">
          <img src="${product.image}" class="product-image" />
          <div class="product-info">
            <h3>${product.mobileModel}</h3>
            <div class="product-price">₹${product.price?.toLocaleString?.() || "N/A"}</div>
            <div class="product-actions">
              <button class="btn btn-primary btn-small" onclick="showProductInfo('${
                product.mobileModel
              }')">View Details</button>
              ${
                currentUser
                  ? `<button class="btn btn-secondary btn-small" onclick="showEMICalculator('${product.mobileModel}')">EMI</button>`
                  : ""
              }
            </div>
          </div>
        </div>
      `,
    )
    .join("");
}

async function loadProducts() {
  try {
    const response = await fetch("http://localhost:8082/devices");
    const backendDevices = await response.json();
    console.log(backendDevices);

    const mergedProducts = sampleProducts.map((staticProduct) => {
      const backendMatch = backendDevices.find(
        (backendProduct) => backendProduct.mobileModel.toLowerCase() === staticProduct.mobileModel.toLowerCase(),
      );

      return {
        ...staticProduct,
        ...(backendMatch || {}), // adds dynamic fields: deviceId, price, deviceStatus
        // ⭐ FIX: Ensure brand is set and in lowercase for consistent filtering
        brand: backendMatch?.brand?.toLowerCase() || staticProduct.mobileModel.split(" ")[0].toLowerCase(), 
      };
    });

    products = mergedProducts; // Update the global products array
    renderProducts(products); // Render with the updated global products array
  } catch (error) {
    console.error("Error fetching backend data:", error);
    // If backend fails, use only sampleProducts as a fallback
    products = sampleProducts.map((staticProduct) => ({
      ...staticProduct,
      price: Math.floor(Math.random() * (150000 - 30000 + 1)) + 30000, // Assign a dummy price
      id: Date.now() + Math.random(), // Assign a dummy ID for view details and EMI to work
      // ⭐ FIX: Infer brand from name and lowercase it for consistency
      brand: staticProduct.mobileModel.split(" ")[0].toLowerCase(), 
    }));
    renderProducts(products);
  }
}

function showProductInfo(mobileModel) {
  const product = products.find((p) => p.mobileModel === mobileModel);
  if (!product) return;

  const container = document.getElementById("product-info-container");
  container.innerHTML = `
    <div class="product-detail">
      <img src="${product.image}" class="product-detail-image"/>
      <div class="product-detail-info">
        <h1>${product.mobileModel}</h1>
        <div class="product-detail-price">₹${product.price?.toLocaleString() || "N/A"}</div>
        <div class="product-specs">
          <h3>Specifications</h3>
          <ul>
            ${Object.entries(product.specs)
              .map(([key, value]) => `<li><span>${key}</span><span>${value}</span></li>`)
              .join("")}
          </ul>
        </div>
        <div class="product-actions">
          ${
            currentUser
              ? `
            <button class="btn btn-primary" onclick="showEMICalculator('${product.mobileModel}')">Calculate EMI</button>
            <button class="btn btn-secondary" onclick="showPage('products')">Back to Products</button>
          `
              : `
            <button class="btn btn-primary" onclick="showPage('login')">Login to Buy</button>
            <button class="btn btn-secondary" onclick="showPage('products')">Back to Products</button>
          `
          }
        </div>
      </div>
    </div>
  `;

  showPage("product-info");
}

function filterProducts() {
  renderProducts(products); 
}

function showEMICalculator(mobileModel) {
  if (!currentUser) {
    alert("Please login to calculate EMI");
    return;
  }

  const product = products.find((p) => p.mobileModel === mobileModel);
  if (!product) return;

  document.getElementById("product-price").textContent = product.price?.toLocaleString() || "N/A";
  document.getElementById("emi-modal").style.display = "block";
  document.getElementById("total-amount").textContent = product.price?.toLocaleString() || "N/A";

  // Store current product for purchase
  window.currentProduct = product;

  calculateEMI();
}

function calculateEMI() {
  const product = window.currentProduct;
  if (!product) return;

  const months = Number.parseInt(document.getElementById("emi-months").value);
  const monthlyEMI = Math.ceil(product.price / months);
  document.getElementById("monthly-emi").textContent = monthlyEMI.toLocaleString();
}


async function purchaseProduct() {
  if (!currentUser) {
    alert("Please login to purchase");
    return;
  }

  const product = window.currentProduct;
  if (!product) {
    alert("No product selected for purchase.");
    return;
  }

  const months = Number.parseInt(document.getElementById("emi-months").value);
  const monthlyEMI = Math.ceil(product.price / months);

  // --- Step 1: Fetch user's card information to get available limit and card number ---
  let userCard = null;
  let cardLimit = 0; // The total limit of the card
  let cardNumber = '';
  let fetchedCardDetails = null; // To store full card object for update later

  try {
    const cardsResponse = await fetch("http://localhost:8081/api/cards");
    if (!cardsResponse.ok) {
      throw new Error(`Failed to fetch cards: ${cardsResponse.status} ${cardsResponse.statusText}`);
    }
    const backendCards = await cardsResponse.json();
    userCard = backendCards.find(card => card.user.userId === currentUser.id);

    if (userCard) {
      cardLimit = userCard.cardLimit; // This is the total credit limit
      cardNumber = userCard.cardNumber;
      fetchedCardDetails = userCard; // Store the entire object for updating
    } else {
      alert("No active card found for your account. Cannot proceed with purchase.");
      return;
    }
  } catch (error) {
    console.error("Error fetching card data:", error);
    alert(`Failed to retrieve card information for credit check. Error: ${error.message}`);
    return;
  }

  // --- Step 2: Check credit limit ---
  // The available limit for purchase check is still the card's total limit as specified.
  const availableCreditForPurchase = cardLimit;

  if (product.price > availableCreditForPurchase) {
    alert(`Insufficient credit limit! Product price (₹${product.price.toLocaleString()}) exceeds your card limit (₹${availableCreditForPurchase.toLocaleString()}).`);
    return;
  }

  // --- Step 3: Fetch deviceId for the product ---
  let deviceId = null;
  try {
    const devicesResponse = await fetch("http://localhost:8082/devices");
    if (!devicesResponse.ok) {
      throw new Error(`Failed to fetch devices: ${devicesResponse.status} ${devicesResponse.statusText}`);
    }
    const backendDevices = await devicesResponse.json();
    const matchedDevice = backendDevices.find(device => device.mobileModel === product.mobileModel);

    if (matchedDevice) {
      deviceId = matchedDevice.deviceId;
    } else {
      alert(`Could not find device ID for product: ${product.mobileModel}. Cannot proceed with purchase.`);
      return;
    }
  } catch (error) {
    console.error("Error fetching device data:", error);
    alert(`Failed to retrieve device details for purchase. Error: ${error.message}`);
    return;
  }

  // --- Step 4: Generate loanID and prepare loan data for backend ---
  const loanID = Math.floor(Math.random() * (20000 - 1000 + 1)) + 1000;

  const loanStartDate = new Date();
  const loanEndDate = new Date();
  loanEndDate.setMonth(loanEndDate.getMonth() + months);

  const loanData = {
    loanID: loanID,
    cardNumber: cardNumber,
    deviceId: deviceId,
    loanAmount: product.price,
    status: "active",
    emiPlan: months, // ⭐ Changed to number only
    monthlyEMI: monthlyEMI,
    amountPaid: 0,
    loanStartDate: loanStartDate.toISOString(),
    loanEndDate: loanEndDate.toISOString(),
  };

  // --- Step 5: Send loan request to backend ---
  try {
    const loanResponse = await fetch("http://localhost:8083/api/loans", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(loanData),
    });

    if (!loanResponse.ok) {
      const errorData = await loanResponse.json().catch(() => ({ message: "Unknown error" }));
      throw new Error(`Failed to create loan in backend: ${loanResponse.status} ${loanResponse.statusText} - ${errorData.message || ''}`);
    }

    const createdLoan = await loanResponse.json();
    console.log("Loan successfully created in backend:", createdLoan);

    // --- Step 6: Update card's available limit in the card table ---
    const updatedAvailableLimit = cardLimit - product.price;

    // Create the updated card object (assume only cardLimit needs to change, other fields remain same)
    const updatedCard = { ...fetchedCardDetails,
      cardLimit: updatedAvailableLimit
    }; // Spread existing details and update cardLimit

    try {
      const cardUpdateResponse = await fetch(`http://localhost:8081/api/cards/${cardNumber}`, { // Use cardNumber in URL
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedCard), // Send the updated card object
      });

      if (!cardUpdateResponse.ok) {
        const errorData = await cardUpdateResponse.json().catch(() => ({
          message: "Unknown error during card update"
        }));
        console.warn(`Failed to update card limit in backend: ${cardUpdateResponse.status} ${cardUpdateResponse.statusText} - ${errorData.message || ''}`);
        alert("Purchase successful, but failed to update card limit. Please check your card statement.");
      } else {
        console.log("Card limit successfully updated in backend.");
        alert("Purchase successful! Loan created and card limit updated.");
      }
    } catch (cardError) {
      console.error("Error updating card limit:", cardError);
      alert(`Purchase successful, but encountered an error updating card limit: ${cardError.message}`);
    }

    document.getElementById("emi-modal").style.display = "none";

    // Refresh dashboard to reflect changes (e.g., loan count, card limit)
    if (currentPage === "dashboard") {
      loadDashboard();
    }
  } catch (error) {
    console.error("Error during purchase or loan creation:", error);
    alert(`Purchase failed: ${error.message}`);
  }
}

// Utility functions
function formatCurrency(amount) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
  }).format(amount);
}

function formatDate(dateString) {
  return new Date(dateString).toLocaleDateString("en-IN");
}

// Add some sample users and applications for demo
function addSampleData() {
  // Add sample approved user
  const sampleUser = {
    id: 1001,
    fullName: "John Doe",
    email: "john@example.com",
    phone: "9876543210",
    password: "password123",
    cardType: "gold",
    aadhar: "1234-5678-9012",
    pan: "ABCDE1234F",
    income: "50000",
    status: "approved",
    appliedDate: new Date().toISOString(),
    role: "user",
  };

  if (!users.find((u) => u.email === sampleUser.email)) {
    users.push(sampleUser);
    localStorage.setItem("users", JSON.stringify(users));
  }

  // Add sample pending application
  const sampleApp = {
    id: 2001,
    fullName: "Jane Smith",
    email: "jane@example.com",
    phone: "9876543211",
    password: "password123",
    cardType: "titanium",
    aadhar: "1234-5678-9013",
    pan: "ABCDE1234G",
    income: "75000",
    status: "pending",
    appliedDate: new Date().toISOString(),
    role: "user",
  };

  if (!applications.find((a) => a.email === sampleApp.email)) {
    applications.push(sampleApp);
    localStorage.setItem("applications", JSON.stringify(applications));
  }
}


// Ensure the Confetti.js library is loaded in your HTML:
// <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js"></script>

async function completeLoan(loanID) {
  console.log(`Attempting to mark loan ${loanID} as completed.`);

  // --- Confetti Animation ---
  confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
  });
  setTimeout(() => {
      confetti({
          particleCount: 75,
          spread: 90,
          origin: { y: 0.7, x: 0.2 }
      });
  }, 200);
  setTimeout(() => {
      confetti({
          particleCount: 75,
          spread: 90,
          origin: { y: 0.7, x: 0.8 }
      });
  }, 400);
  // --- End Confetti Animation ---

  try {
      // Step 1: Fetch the current loan details
      console.log(`Fetching loan details for loanID: ${loanID}`);
      const getResponse = await fetch(`http://localhost:8083/api/loans/${loanID}`);

      if (!getResponse.ok) {
          const errorText = await getResponse.text();
          throw new Error(`Failed to fetch loan ${loanID} details: Status ${getResponse.status}, ${errorText}`);
      }

      const loan = await getResponse.json();
      console.log('Original loan details fetched:', loan);

      // Step 2: Update the loan status to 'completed'
      // Create a new object to avoid direct mutation if 'loan' is a proxy/observable
      const updatedLoan = { ...loan, status: 'completed' };
      
      // Ensure loanID is correctly set in the updated object if your backend expects it in the body
      // (Often, the ID is just in the URL for PUT, but including it in body is also common)
      updatedLoan.loanID = loanID; 

      console.log('Updated loan object for PUT:', updatedLoan);

      // Step 3: Send a PUT request with the updated loan object
      const putResponse = await fetch(`http://localhost:8083/api/loans`, { // PUT to /api/loans
          method: 'PUT',
          headers: {
              'Content-Type': 'application/json',
              // Add any authorization headers if needed
              // 'Authorization': 'Bearer YOUR_AUTH_TOKEN'
          },
          body: JSON.stringify(updatedLoan),
      });

      if (putResponse.ok) {
          console.log(`Loan ${loanID} successfully marked as completed on backend.`);
          alert(`Loan ${loanID} has been successfully marked as completed!`);

          // Step 4: Update the UI
          // Option A: If you have a global function to reload all active loans (recommended)
          // Example: if (typeof loadDashboard === 'function') { loadDashboard(); }
          // Example: if (typeof fetchAndDisplayLoans === 'function') { fetchAndDisplayLoans(); }
          // For now, we'll use a direct DOM removal as a fallback or primary method
          const loanCardElement = document.querySelector(`.loan-card[data-loan-id="${loanID}"]`);
          if (loanCardElement) {
              loanCardElement.remove();
              // If after removal, there are no active loans, display the "No active loans" message
              const container = document.getElementById("active-loans-container");
              if (container && container.children.length === 0) {
                  container.innerHTML = '<p class="no-data">No active loans. <a href="#" data-page="products">Browse products</a></p>';
              }
          }
          showPage('dashboard'); // Navigate back to the dashboard or relevant page

      } else {
          const errorText = await putResponse.text();
          console.error(`Failed to update loan ${loanID} status:`, errorText);
          alert(`Failed to mark loan ${loanID} as completed: ${errorText}`);
      }
  } catch (error) {
      console.error(`Error in completeLoan for ${loanID}:`, error);
      alert(`An unexpected error occurred while trying to complete loan ${loanID}: ${error.message}`);
  }
}

// Initialize sample data on first load
if (localStorage.getItem("sampleDataLoaded") !== "true") {
  addSampleData();
  localStorage.setItem("sampleDataLoaded", "true");
}


