package com.example.demo.entity;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name = "emi_table") // Use a meaningful table name
public class Emi {
    @Id
    private int emiPaymentID;
//    @ManyToOne
//	@JoinColumn(name = "device_id") // Ensure this matches the physical column name in the DB
//	private Device device;
//	private int deviceId;
//	@Transient
//	private Device device; // for API use only, not stored in DB
	@ManyToOne
	@JoinColumn(name = "loan_id") // Ensure this matches the physical column name in the database
    private Loan loan;
	private int emiNumber;
    @Temporal(TemporalType.DATE)
    private Date dueDate;
    @Temporal(TemporalType.DATE)
    private Date paymentDate;
    private double amountPaid;
    private String paymentStatus;
    // Constructors
    public Emi() {
    }

	public Emi(int emiPaymentID, Loan loan, int emiNumber, Date dueDate, Date paymentDate, double amountPaid,
			String paymentStatus) {
        this.emiPaymentID = emiPaymentID;
		this.loan = loan;
        this.emiNumber = emiNumber;
        this.dueDate = dueDate;
        this.paymentDate = paymentDate;
        this.amountPaid = amountPaid;
        this.paymentStatus = paymentStatus;
    }
    // Getters and Setters
    public int getEmiPaymentID() {
        return emiPaymentID;
    }
    public void setEmiPaymentID(int emiPaymentID) {
        this.emiPaymentID = emiPaymentID;
    }

	public Loan getLoan() {
		return loan;
    }

	public void setLoan(Loan loan) {
		this.loan = loan;
    }
    public int getEmiNumber() {
        return emiNumber;
    }
    public void setEmiNumber(int emiNumber) {
        this.emiNumber = emiNumber;
    }
    public Date getDueDate() {
        return dueDate;
    }
    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }
    public Date getPaymentDate() {
        return paymentDate;
    }
    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }
    public double getAmountPaid() {
        return amountPaid;
    }
    public void setAmountPaid(double amountPaid) {
        this.amountPaid = amountPaid;
    }
    public String getPaymentStatus() {
        return paymentStatus;
    }
    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
    // Optional method to display details
    public void showEMIDetails() {
        System.out.println("EMI Payment ID  : " + emiPaymentID);
		System.out.println("Loan ID         : " + (loan != null ? loan.getLoanID() : "null"));
        System.out.println("EMI Number      : " + emiNumber);
        System.out.println("Due Date        : " + dueDate);
        System.out.println("Payment Date    : " + paymentDate);
        System.out.println("Amount Paid     : " + amountPaid);
        System.out.println("Payment Status  : " + paymentStatus);
    }
}