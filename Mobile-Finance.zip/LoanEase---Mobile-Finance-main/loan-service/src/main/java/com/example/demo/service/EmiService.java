package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Emi;
import com.example.demo.vo.EmiDTO;
public interface EmiService {
	// Create or update an EMI record
	Emi saveEmi(EmiDTO dto);

	// Read an EMI record by EMI payment ID
	Optional<Emi> getEmiById(int emiPaymentID);

	// Read all EMI records
	List<Emi> getAllEmis();

	// Update an existing EMI record
	Emi updateEmi(int emiPaymentID, Emi emi);

	// Delete an EMI record by EMI payment ID
	void deleteEmi(int emiPaymentID);

	public List<Emi> getEmisByLoanId(int loanId);

}