package com.example.demo.vo;

public class Device {
	private Long deviceId;
	private String mobileModel;
	private Double price;
	private String deviceStatus;

	// No-args constructor (needed for deserialization)
	public Device() {
	}

	// All-args constructor
	public Device(Long deviceId, String mobileModel, Double price, String deviceStatus) {
		this.deviceId = deviceId;
		this.mobileModel = mobileModel;
		this.price = price;
		this.deviceStatus = deviceStatus;
	}

	public Long getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(Long deviceId) {
		this.deviceId = deviceId;
	}

	public String getMobileModel() {
		return mobileModel;
	}

	public void setMobileModel(String mobileModel) {
		this.mobileModel = mobileModel;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getDeviceStatus() {
		return deviceStatus;
	}

	public void setDeviceStatus(String deviceStatus) {
		this.deviceStatus = deviceStatus;
	}

}