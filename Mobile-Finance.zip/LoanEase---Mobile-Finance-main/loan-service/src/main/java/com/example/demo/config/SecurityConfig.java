// src/main/java/com/yourproject/config/SecurityConfig.java (Example filename)
// Make sure this is in your loan service project, not the others.

package com.example.demo.config;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod; // Import HttpMethod
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration // Marks this class as a Spring configuration source
@EnableWebSecurity // Enables Spring Security's web security features
public class SecurityConfig {

	@Bean // Defines a bean for the security filter chain
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http
				// Disable CSRF for API development (be cautious in production; consider
				// token-based auth)
				.csrf(csrf -> csrf.disable())
				// Configure authorization rules for HTTP requests
				.authorizeHttpRequests(auth -> auth
						// ⭐ Crucially, permit all OPTIONS requests globally for preflight
						.requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
						// ⭐ Permit all requests to your API endpoints without authentication
						// Adjust "/api/**" if your loan controller uses a different base path, e.g.,
						// "/loans/**"
						.requestMatchers("/api/**", "/swagger-ui/**", "/swagger-ui.html", "/v3/api-docs/**",
								"/swagger-resources/**", "/webjars/**")
						.permitAll()
						// All other requests require authentication
						.anyRequest().authenticated())
				// ⭐ Enable CORS processing within Spring Security
				.cors(cors -> cors.configurationSource(corsConfigurationSource()));

		return http.build();
	}

	// ⭐ This bean defines the detailed CORS policy
	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration configuration = new CorsConfiguration();
		// ⭐ List all origins that are allowed to access your backend
		configuration.setAllowedOrigins(Arrays.asList("http://127.0.0.1:5500", "http://localhost:5500"));
		// ⭐ List all HTTP methods allowed for cross-origin requests, including OPTIONS
		configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
		// Allow all headers from the client
		configuration.setAllowedHeaders(Collections.singletonList("*"));
		// Allow sending credentials like cookies or authorization headers
		configuration.setAllowCredentials(true);
		// How long the preflight response can be cached by the browser (in seconds)
		configuration.setMaxAge(3600L);

		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		// Apply this CORS configuration to all paths (or specific API paths like
		// "/api/**")
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}



}