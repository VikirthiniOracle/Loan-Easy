package com.example.demo.vo;

import java.util.Date;

public class EmiDTO {
	private int emiPaymentID;
	private int loanId; // Just loan ID, not full object
	private int emiNumber;
	private Date dueDate;
	private Date paymentDate;
	private double amountPaid;
	private String paymentStatus;

	// Constructors
	public EmiDTO() {
	}

	public EmiDTO(int emiPaymentID, int loanId, int emiNumber, Date dueDate, Date paymentDate, double amountPaid,
			String paymentStatus) {
		this.emiPaymentID = emiPaymentID;
		this.loanId = loanId;
		this.emiNumber = emiNumber;
		this.dueDate = dueDate;
		this.paymentDate = paymentDate;
		this.amountPaid = amountPaid;
		this.paymentStatus = paymentStatus;
	}

	// Getters and Setters
	public int getEmiPaymentID() {
		return emiPaymentID;
	}

	public void setEmiPaymentID(int emiPaymentID) {
		this.emiPaymentID = emiPaymentID;
	}

	public int getLoanId() {
		return loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public int getEmiNumber() {
		return emiNumber;
	}

	public void setEmiNumber(int emiNumber) {
		this.emiNumber = emiNumber;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public double getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
}
