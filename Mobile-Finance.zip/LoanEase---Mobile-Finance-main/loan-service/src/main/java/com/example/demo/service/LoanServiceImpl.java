package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Loan;
import com.example.demo.feign.DeviceClient;
import com.example.demo.repository.LoanRepo;
import com.example.demo.vo.Device;

import feign.FeignException;

@Service
public class LoanServiceImpl implements LoanService {

	@Autowired
	LoanRepo loanRepo;

	@Autowired
	private DeviceClient deviceClient;

//	@Override
//	public Loan create(Loan loan) {
//		if (loanRepo.existsById(loan.getLoanID())) {
//			throw new AlreadyExistsException("Loan with ID " + loan.getLoanID() + " already exists.");
//		}
//		return loanRepo.save(loan);
//	}

	@Override
	public Loan create(Loan loan) {
		if (loanRepo.existsById(loan.getLoanID())) {
			throw new AlreadyExistsException("Loan with ID " + loan.getLoanID() + " already exists.");
		}

		// ✅ Validate device ID using Feign client
		try {
			ResponseEntity<Device> response = deviceClient.getDeviceById(Long.valueOf(loan.getDeviceId()));
			System.out.println("Fetched device: " + response);

			if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {

				throw new IllegalArgumentException("Device not found");
			}
		} catch (FeignException.NotFound e) {
			System.err.println("Error fetching device: " + e.getMessage());
			throw new IllegalArgumentException("Device with ID " + loan.getDeviceId() + " does not exist");
		}

		return loanRepo.save(loan);
	}


	@Override
	public Loan read(int loanID) {
		return loanRepo.findById(loanID)
				.orElseThrow(() -> new DoesNotExistException("Loan with ID " + loanID + " does not exist."));
	}

	@Override
	public List<Loan> readAll() {
		return loanRepo.findAll();
	}

	@Override
	public Loan update(Loan loan) {
		if (!loanRepo.existsById(loan.getLoanID())) {
			throw new DoesNotExistException("Loan with ID " + loan.getLoanID() + " does not exist.");
		}
		return loanRepo.save(loan);
	}

	@Override
	public void delete(int loanID) {
		if (!loanRepo.existsById(loanID)) {
			throw new DoesNotExistException("Loan with ID " + loanID + " does not exist.");
		}
		loanRepo.deleteById(loanID);
	}

	@Override
	public List<Loan> getLoansByCardNumber(int cardNumber) {
		return loanRepo.findByCardNumber(cardNumber);
	}
}
