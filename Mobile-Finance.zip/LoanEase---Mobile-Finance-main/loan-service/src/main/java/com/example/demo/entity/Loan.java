package com.example.demo.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name = "loan_table")
public class Loan {

    @Id
	@Column(name = "loan_id")
    private int loanID;

	private int cardNumber;

	// If you need card details in response but not stored in DB
	// @Transient
	// private Card card;

	private int deviceId;

//	@Transient
//	private Device device; // for API use only

    private double loanAmount;
    private String status;
    private String emiPlan;
    private double monthlyEMI;
    private double amountPaid;

    @Temporal(TemporalType.DATE)
	@Column(name = "loan_start_date")
    private Date loanStartDate;

    @Temporal(TemporalType.DATE)
	@Column(name = "loan_end_date")
    private Date loanEndDate;

	public Loan() {
	}

	public Loan(int loanID, int cardNumber, double loanAmount, String status,
                String emiPlan, double monthlyEMI, double amountPaid,
                Date loanStartDate, Date loanEndDate) {
        this.loanID = loanID;
		this.cardNumber = cardNumber;
//        this.device = device;
        this.loanAmount = loanAmount;
        this.status = status;
        this.emiPlan = emiPlan;
        this.monthlyEMI = monthlyEMI;
        this.amountPaid = amountPaid;
        this.loanStartDate = loanStartDate;
        this.loanEndDate = loanEndDate;
    }

    // Getters and Setters

    public int getLoanID() {
        return loanID;
    }

    public void setLoanID(int loanID) {
        this.loanID = loanID;
    }

	public int getCardNumber() {
		return cardNumber;
    }

	public void setCardNumber(int cardNumber) {
		this.cardNumber = cardNumber;
    }

//    public Device getDevice() {
//        return device;
//    }
//
//    public void setDevice(Device device) {
//        this.device = device;
//    }

	public int getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(int deviceId) {
		this.deviceId = deviceId;
	}

    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEmiPlan() {
        return emiPlan;
    }

    public void setEmiPlan(String emiPlan) {
        this.emiPlan = emiPlan;
    }

    public double getMonthlyEMI() {
        return monthlyEMI;
    }

    public void setMonthlyEMI(double monthlyEMI) {
        this.monthlyEMI = monthlyEMI;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(double amountPaid) {
        this.amountPaid = amountPaid;
    }

    public Date getLoanStartDate() {
        return loanStartDate;
    }

    public void setLoanStartDate(Date loanStartDate) {
        this.loanStartDate = loanStartDate;
    }

    public Date getLoanEndDate() {
        return loanEndDate;
    }

    public void setLoanEndDate(Date loanEndDate) {
        this.loanEndDate = loanEndDate;
    }

    public void showLoanDetails() {
        System.out.println("Loan ID       : " + loanID);
		System.out.println("Card Number   : " + cardNumber);
		System.out.println("Device ID     : " + deviceId);
        System.out.println("Loan Amount   : " + loanAmount);
        System.out.println("Status        : " + status);
        System.out.println("EMI Plan      : " + emiPlan);
        System.out.println("Monthly EMI   : " + monthlyEMI);
        System.out.println("Amount Paid   : " + amountPaid);
        System.out.println("Start Date    : " + loanStartDate);
        System.out.println("End Date      : " + loanEndDate);
    }
}