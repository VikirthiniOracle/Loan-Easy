package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Transaction;
import com.example.demo.vo.TransactionDTO;
public interface TransactionService {
	// Create a new transaction
	Transaction saveTransaction(TransactionDTO dto);

	// Read a transaction by its ID
	Optional<Transaction> getTransactionById(int transactionId);

	// Read all transactions
	List<Transaction> getAllTransactions();

	// Update a transaction
	Transaction updateTransaction(int transactionId, Transaction transaction);

	// Delete a transaction by its ID
	void deleteTransaction(int transactionId);
}