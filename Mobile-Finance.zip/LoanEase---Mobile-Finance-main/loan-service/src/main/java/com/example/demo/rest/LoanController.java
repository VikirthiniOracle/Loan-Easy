package com.example.demo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Loan;
import com.example.demo.service.LoanService;

@RestController
@RequestMapping("/api/loans")
public class LoanController {

	@Autowired
    private final LoanService loanService;

    public LoanController(LoanService loanService) {
        this.loanService = loanService;
    }

    // Create a new loan
    @PostMapping
    public ResponseEntity<Loan> createLoan(@RequestBody Loan loan) {
		Loan createdLoan = loanService.create(loan);
        return new ResponseEntity<>(createdLoan, HttpStatus.CREATED);
    }

    // Read a loan by ID
    @GetMapping("/{loanID}")
    public ResponseEntity<Loan> getLoanById(@PathVariable int loanID) {
		try {
			Loan loan = loanService.read(loanID);
			return ResponseEntity.ok(loan);
		} catch (Exception e) {
			return ResponseEntity.notFound().build();
		}
    }

    // Read all loans
    @GetMapping
    public List<Loan> getAllLoans() {
		return loanService.readAll();
    }

	// Update a loan
	@PutMapping
	public ResponseEntity<Loan> updateLoan(@RequestBody Loan loan) {
		try {
			Loan updatedLoan = loanService.update(loan);
			return ResponseEntity.ok(updatedLoan);
		} catch (Exception e) {
			return ResponseEntity.notFound().build();
		}
    }

    // Delete a loan by ID
    @DeleteMapping("/{loanID}")
    public ResponseEntity<Void> deleteLoan(@PathVariable int loanID) {
		try {
			loanService.delete(loanID);
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			return ResponseEntity.notFound().build();
		}
    }

	@GetMapping("/card/{cardNumber}")
	public ResponseEntity<List<Loan>> getLoansByCardNumber(@PathVariable int cardNumber) {
		List<Loan> loans = loanService.getLoansByCardNumber(cardNumber);
//		if (loans.isEmpty()) {
//			return ResponseEntity.noContent().build();
//		}
		return ResponseEntity.ok(loans);
	}
}
