package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Emi;
import com.example.demo.entity.Loan;
import com.example.demo.repository.EmiRepo;
import com.example.demo.vo.EmiDTO;

@Service
public class EmiServiceImpl implements EmiService {
	@Autowired
	private EmiRepo emiRepo;

	@Autowired
	private LoanService loanService;

	// Save EMI details
	@Override
	public Emi saveEmi(EmiDTO dto) {
		Loan loan = loanService.read(dto.getLoanId());
		if (loan == null) {
			throw new RuntimeException("Loan with ID " + dto.getLoanId() + " does not exist");
		}
		// Create EMI entity
		Emi emi = new Emi();
		emi.setLoan(loan);
		emi.setEmiPaymentID(dto.getEmiPaymentID());
		emi.setEmiNumber(dto.getEmiNumber());
		emi.setDueDate(dto.getDueDate());
		emi.setPaymentDate(dto.getPaymentDate());
		emi.setAmountPaid(dto.getAmountPaid());
		emi.setPaymentStatus(dto.getPaymentStatus());

		return emiRepo.save(emi);
	}

	// Get EMI by ID
	@Override
	public Optional<Emi> getEmiById(int emiPaymentID) {
		return emiRepo.findById(emiPaymentID);
	}

	// Get all EMI details
	@Override
	public List<Emi> getAllEmis() {
		return emiRepo.findAll();
	}

	// Update EMI details
	@Override
	public Emi updateEmi(int emiPaymentID, Emi emi) {
		if (emiRepo.existsById(emiPaymentID)) {
			emi.setEmiPaymentID(emiPaymentID);
			return emiRepo.save(emi);
		} else {
			throw new RuntimeException("EMI with ID " + emiPaymentID + " not found");
		}
	}

	// Delete EMI details
	@Override
	public void deleteEmi(int emiPaymentID) {
		emiRepo.deleteById(emiPaymentID);
	}

	@Override
	public List<Emi> getEmisByLoanId(int loanId) {
		return emiRepo.findByLoanLoanID(loanId);
	}
}