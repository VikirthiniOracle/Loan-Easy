package com.example.demo.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "transaction_table")
public class Transaction {
    @Id
    private int transactionId;
    @ManyToOne
	@JoinColumn(name = "loan_id") // Ensure this matches the foreign key in your DB (loan_id)
    private Loan loan;


    private String transactionType;
    private double amount;
    private Date transactionDate;
    private String paymentMethod;

	// Remove the loanId field here
	// private int loanId; // Remove this field as it's redundant
    public Transaction() {
        super();
        // Default constructor
    }
    public Transaction(int transactionId, String transactionType, double amount,
			Date transactionDate, String paymentMethod, Loan loan) {
        super();
        this.transactionId = transactionId;
        this.transactionType = transactionType;
        this.amount = amount;
        this.transactionDate = transactionDate;
        this.paymentMethod = paymentMethod;
		this.loan = loan; // Pass Loan object directly
    }

	// Getters and Setters
    public int getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }
    public String getTransactionType() {
        return transactionType;
    }
    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }
    public double getAmount() {
        return amount;
    }
    public void setAmount(double amount) {
        this.amount = amount;
    }
    public Date getTransactionDate() {
        return transactionDate;
    }
    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }
    public String getPaymentMethod() {
        return paymentMethod;
    }
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

	public Loan getLoan() {
		return loan;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}
    // Optional display method
    public void showTransactionDetails() {
        System.out.println("Transaction ID   : " + transactionId);
        System.out.println("Transaction Type : " + transactionType);
        System.out.println("Amount (₹)       : " + amount);
        System.out.println("Transaction Date : " + transactionDate);
        System.out.println("Payment Method   : " + paymentMethod);
		System.out.println("Loan ID          : " + (loan != null ? loan.getLoanID() : "null"));
        System.out.println("--------------------------------------------------");
    }
}