package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Loan;
import com.example.demo.entity.Transaction;
import com.example.demo.repository.TransactionRepo;
import com.example.demo.vo.TransactionDTO;

@Service
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	private final TransactionRepo transactionRepo;

	@Autowired
	private LoanService loanService;

	public TransactionServiceImpl(TransactionRepo transactionRepo) {
		this.transactionRepo = transactionRepo;
	}

	public Transaction saveTransaction(TransactionDTO dto) {
		Loan loan = loanService.read(dto.getLoanId());
		if (loan == null) {
			throw new RuntimeException("Loan with ID " + dto.getLoanId() + " does not exist");
		}

		Transaction transaction = new Transaction();
		transaction.setTransactionId(dto.getTransactionId());
		transaction.setAmount(dto.getAmount());
		transaction.setTransactionType(dto.getTransactionType());
		transaction.setTransactionDate(dto.getTransactionDate());
		transaction.setLoan(loan);

		return transactionRepo.save(transaction);
	}

	@Override
	public Optional<Transaction> getTransactionById(int transactionId) {
		return transactionRepo.findById(transactionId); // Retrieve a transaction by its ID
	}

	@Override
	public List<Transaction> getAllTransactions() {
		return transactionRepo.findAll(); // Retrieve all transactions
	}

	@Override
	public Transaction updateTransaction(int transactionId, Transaction transaction) {
		if (transactionRepo.existsById(transactionId)) {
			transaction.setTransactionId(transactionId); // Update existing transaction
			return transactionRepo.save(transaction);
		}
		return null; // Return null if transaction not found
	}

	@Override
	public void deleteTransaction(int transactionId) {
		if (transactionRepo.existsById(transactionId)) {
			transactionRepo.deleteById(transactionId); // Delete the transaction
		}
	}
}