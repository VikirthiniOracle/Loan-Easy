package com.example.demo.vo;

import java.util.Date;

public class TransactionDTO {
	private int transactionId;
	private String transactionType;
	private double amount;
	private Date transactionDate;
	private String paymentMethod;
	private int loanId; // Just the ID, not the full Loan object

	public TransactionDTO() {
		// Default constructor
	}

	public TransactionDTO(int transactionId, String transactionType, double amount, Date transactionDate,
			String paymentMethod, int loanId) {
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.amount = amount;
		this.transactionDate = transactionDate;
		this.paymentMethod = paymentMethod;
		this.loanId = loanId;
	}

	// Getters and Setters

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public int getLoanId() {
		return loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}
}
