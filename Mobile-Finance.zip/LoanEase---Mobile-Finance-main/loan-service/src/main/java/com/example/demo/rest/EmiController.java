package com.example.demo.rest;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Emi;
import com.example.demo.service.EmiService;
import com.example.demo.vo.EmiDTO;

@RestController
@RequestMapping("/api/emi")
public class EmiController {

    @Autowired
    private EmiService emiService;


    // Endpoint to create or save a new EMI
    @PostMapping
	public ResponseEntity<Emi> createEmi(@RequestBody EmiDTO emiDTO) {
		Emi savedEmi = emiService.saveEmi(emiDTO);
        return new ResponseEntity<>(savedEmi, HttpStatus.CREATED);
    }

    // Endpoint to get EMI by ID
    @GetMapping("/{emiPaymentID}")
    public ResponseEntity<Emi> getEmiById(@PathVariable int emiPaymentID) {
        Optional<Emi> emi = emiService.getEmiById(emiPaymentID);
        if (emi.isPresent()) {
            return new ResponseEntity<>(emi.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Endpoint to get all EMIs
    @GetMapping
    public List<Emi> getAllEmis() {
        return emiService.getAllEmis();
    }

    // Endpoint to update EMI by ID
    @PutMapping("/{emiPaymentID}")
    public ResponseEntity<Emi> updateEmi(@PathVariable int emiPaymentID, @RequestBody Emi emi) {
        try {
            Emi updatedEmi = emiService.updateEmi(emiPaymentID, emi);
            return new ResponseEntity<>(updatedEmi, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Endpoint to delete EMI by ID
    @DeleteMapping("/{emiPaymentID}")
    public ResponseEntity<Void> deleteEmi(@PathVariable int emiPaymentID) {
        emiService.deleteEmi(emiPaymentID);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

	@GetMapping("/loan/{loanId}")
	public List<Emi> getEmisByLoanId(@PathVariable int loanId) {
		return emiService.getEmisByLoanId(loanId);
	}
}
