package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Loan;

public interface LoanService {
	Loan create(Loan loan);

	Loan read(int loanID);

	List<Loan> readAll();

	Loan update(Loan loan);

	void delete(int loanID);

	public List<Loan> getLoansByCardNumber(int cardNumber);
}
