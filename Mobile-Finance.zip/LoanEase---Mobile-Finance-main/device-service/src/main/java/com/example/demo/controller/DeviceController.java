package com.example.demo.controller;

import com.example.demo.entity.Device;
import com.example.demo.service.DeviceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/devices")
@CrossOrigin(origins = "*") // Enables access from Swagger/Frontend
public class DeviceController {

    @Autowired
    private DeviceService deviceService;

    // Create
    @PostMapping
    public ResponseEntity<Device> createDevice(@RequestBody Device newDevice) {
        return ResponseEntity.status(201).body(deviceService.create(newDevice));
    }

    // Read one
    @GetMapping("/{deviceId}")
    public ResponseEntity<Device> getDevice(@PathVariable Long deviceId) {
        return ResponseEntity.ok(deviceService.read(deviceId));
    }

    // Read all
    @GetMapping
    public ResponseEntity<List<Device>> getAllDevices() {
        return ResponseEntity.ok(deviceService.readAll());
    }

    // Update
    @PutMapping("/{deviceId}")
    public ResponseEntity<Device> updateDevice(@PathVariable Long deviceId, @RequestBody Device updatedDevice) {
        updatedDevice.setDeviceId(deviceId);
        return ResponseEntity.ok(deviceService.update(updatedDevice));
    }

    // Delete
    @DeleteMapping("/{deviceId}")
    public ResponseEntity<String> deleteDevice(@PathVariable Long deviceId) {
        deviceService.delete(deviceId);
        return ResponseEntity.ok("Device deleted successfully");
    }
}
