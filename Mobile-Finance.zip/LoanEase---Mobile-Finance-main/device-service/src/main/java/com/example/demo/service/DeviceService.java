package com.example.demo.service;

import com.example.demo.entity.Device;
import java.util.List;

public interface DeviceService {
    Device create(Device newDevice);
    Device read(Long deviceId);
    List<Device> readAll();
    Device update(Device updatedDevice);
    void delete(Long deviceId);
}
