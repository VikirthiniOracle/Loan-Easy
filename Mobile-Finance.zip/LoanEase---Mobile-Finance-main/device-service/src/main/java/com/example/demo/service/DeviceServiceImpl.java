package com.example.demo.service;

import com.example.demo.entity.Device;
import com.example.demo.repository.DeviceRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeviceServiceImpl implements DeviceService {

    @Autowired
    private DeviceRepo deviceRepo;

    @Override
    public Device create(Device newDevice) {
        return deviceRepo.save(newDevice);
    }

    @Override
    public Device read(Long deviceId) {
        return deviceRepo.findById(deviceId)
                .orElseThrow(() -> new RuntimeException("Device not found with ID: " + deviceId));
    }

    @Override
    public List<Device> readAll() {
        return deviceRepo.findAll();
    }

    @Override
    public Device update(Device updatedDevice) {
        if (!deviceRepo.existsById(updatedDevice.getDeviceId())) {
            throw new RuntimeException("Device not found with ID: " + updatedDevice.getDeviceId());
        }
        return deviceRepo.save(updatedDevice);
    }

    @Override
    public void delete(Long deviceId) {
        if (!deviceRepo.existsById(deviceId)) {
            throw new RuntimeException("Device not found with ID: " + deviceId);
        }
        deviceRepo.deleteById(deviceId);
    }
}
